<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Masuk - Presensi Fingerprint</title>
<link rel="icon" href="{{ asset('img/logo.png') }}">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;grid-template-columns:1.1fr 1fr;font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1b2433;background:#f3f6fb}
.hero{background:linear-gradient(165deg,rgba(8,40,100,.9),rgba(21,89,193,.5)),url('{{ asset('img/gedung.jpg') }}') center/cover;color:#fff;padding:48px;display:flex;flex-direction:column;justify-content:flex-end;gap:12px}
.hero img{width:76px;height:76px;background:#fff;border-radius:50%;padding:5px}
.hero h1{margin:0;font-size:2rem;line-height:1.15;max-width:18ch}
.hero p{margin:0;max-width:44ch;opacity:.92}
.panel{display:flex;align-items:center;justify-content:center;padding:24px}
.box{width:100%;max-width:380px;background:#fff;border:1px solid #e3e8f0;border-radius:14px;padding:28px}
.box h2{margin:0 0 4px;font-size:1.3rem}
.muted{color:#667085;font-size:.9rem;margin:0 0 16px}
label{display:block;margin:12px 0 4px;font-size:.9rem}
input[type=text],input[type=password]{width:100%;padding:10px 12px;border:1px solid #cfd8e6;border-radius:8px;font:inherit}
input:focus-visible,button:focus-visible{outline:2px solid #1559c1;outline-offset:2px}
.show{display:flex;gap:6px;align-items:center;font-size:.85rem;color:#667085;margin:10px 0 0}
button{width:100%;margin-top:18px;padding:11px;border:0;border-radius:8px;background:#1559c1;color:#fff;font:inherit;font-weight:600;cursor:pointer}
.err{color:#b91c1c;margin:10px 0 0;font-size:.9rem}
@media(max-width:820px){body{grid-template-columns:1fr}.hero{padding:28px 24px;min-height:230px}.hero h1{font-size:1.45rem}.hero img{width:56px;height:56px}.panel{padding:16px}}
</style>
</head>
<body>
<section class="hero">
    <img src="{{ asset('img/logo.png') }}" alt="Logo SMK Muhammadiyah 2 Metro">
    <h1>Presensi Fingerprint SMK Muhammadiyah 2 Metro</h1>
    <p>Pantau kehadiran siswa dari data mesin fingerprint, langsung dari HP atau komputer.</p>
</section>
<section class="panel">
    <div class="box">
        <h2>Masuk</h2>
        <p class="muted">Guru memakai NIP dan password JIBAS. Orang tua, kesiswaan, kepala sekolah, dan admin memakai akun dari sekolah.</p>
        <form method="post" action="{{ url('/login') }}">
            @csrf
            <label for="login">NIP / Username</label>
            <input type="text" id="login" name="login" value="{{ old('login') }}" autocomplete="username" required autofocus>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" autocomplete="current-password" required>
            <label class="show"><input type="checkbox" onclick="document.getElementById('password').type=this.checked?'text':'password'"> Tampilkan password</label>
            @error('login') <div class="err">{{ $message }}</div> @enderror
            @error('password') <div class="err">{{ $message }}</div> @enderror
            <button type="submit">Masuk</button>
        </form>
    </div>
</section>
</body>
</html>
