<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'Presensi Fingerprint')</title>
<link rel="icon" href="{{ asset('img/logo.png') }}">
<style>
:root{--bg:#f3f6fb;--card:#fff;--text:#1b2433;--muted:#667085;--line:#e3e8f0;--brand:#1559c1;--soft:#e8f0fe;--ok:#15803d;--warn:#b45309;--bad:#b91c1c;--side:236px}
@media(prefers-color-scheme:dark){:root{--bg:#0f172a;--card:#182235;--text:#f1f5f9;--muted:#94a3b8;--line:#2a374d;--brand:#6ea0ff;--soft:#1e2f52;--ok:#4ade80;--warn:#fbbf24;--bad:#f87171}}
*{box-sizing:border-box}
body{margin:0;font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--text)}
a{color:var(--brand)}
:focus-visible{outline:2px solid var(--brand);outline-offset:2px}
.side{position:fixed;inset:0 auto 0 0;width:var(--side);background:var(--card);border-right:1px solid var(--line);padding:16px 12px;display:flex;flex-direction:column;gap:18px}
.logo{display:flex;gap:10px;align-items:center;text-decoration:none;color:var(--text)}
.logo img{width:40px;height:40px}
.logo b{display:block;font-size:.95rem;line-height:1.2}
.logo small{color:var(--muted);font-size:.75rem}
.side nav{display:flex;flex-direction:column;gap:2px}
.side nav a{padding:9px 12px;border-radius:8px;color:var(--text);text-decoration:none}
.side nav a:hover{background:var(--bg)}
.side nav a.on{background:var(--soft);color:var(--brand);font-weight:600}
.col{margin-left:var(--side);min-height:100vh}
.top{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:12px 24px;background:var(--card);border-bottom:1px solid var(--line)}
.top form{display:flex;gap:12px;align-items:center;margin:0}
.who{text-align:right;line-height:1.2}
.who small{color:var(--muted)}
.tt{font-weight:600}
.mob{display:none;align-items:center;gap:8px;font-weight:600}
.mob img{width:28px;height:28px}
main{max-width:1040px;margin:0 auto;padding:24px}
h1{font-size:1.3rem;margin:0 0 12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:16px}
.muted{color:var(--muted);font-size:.9rem}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}
.stats{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}
.pill{padding:2px 10px;border-radius:999px;font-size:.85rem;border:1px solid var(--line)}
.pill.ok,.pill.warn,.pill.bad{border-color:transparent;background:color-mix(in srgb,currentColor 13%,transparent)}
.ok{color:var(--ok)}.warn{color:var(--warn)}.bad{color:var(--bad)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:12px 0 16px}
.kpi{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--c,var(--brand));border-radius:10px;padding:12px 14px}
.kpi b{display:block;font-size:1.7rem;line-height:1.15}
.kpi span{color:var(--muted);font-size:.85rem}
.bar{height:8px;min-width:80px;background:var(--line);border-radius:99px}
.bar i{display:block;height:100%;border-radius:99px;background:var(--ok)}
table{width:100%;border-collapse:collapse;font-size:.95rem}
th,td{text-align:left;padding:9px 8px;border-bottom:1px solid var(--line);vertical-align:middle}
th{font-size:.82rem;font-weight:600;color:var(--muted);background:var(--bg)}
tbody tr:hover{background:var(--bg)}
.wrap{overflow-x:auto}
input,select,textarea,button{font:inherit;padding:8px 10px;border-radius:8px;border:1px solid var(--line);background:var(--card);color:var(--text)}
textarea{width:100%}
button,.btn{background:var(--brand);color:#fff;border:0;cursor:pointer;text-decoration:none;display:inline-block;padding:8px 14px;border-radius:8px}
.btn.ghost{background:transparent;color:var(--brand);border:1px solid var(--brand)}
.btn.danger{background:var(--bad)}
form.inline{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
.err{color:var(--bad);margin:8px 0}
.flash{border-color:var(--ok);color:var(--ok)}
label{display:block;margin:12px 0 4px;font-size:.9rem}
.field{width:100%}
.tabs{display:none}
@media(max-width:860px){
.side{display:none}.col{margin-left:0;padding-bottom:68px}.top{padding:10px 16px}.tt{display:none}.mob{display:flex}main{padding:16px}
.who small{display:none}
.tabs{display:flex;position:fixed;inset:auto 0 0 0;z-index:5;background:var(--card);border-top:1px solid var(--line);padding-bottom:env(safe-area-inset-bottom)}
.tabs a{flex:1;text-align:center;padding:12px 4px;font-size:.78rem;color:var(--muted);text-decoration:none}
.tabs a.on{color:var(--brand);font-weight:600}}
@media print{.side,.top,.tabs,.no-print{display:none!important}.col{margin:0}body{background:#fff;color:#000}.card{border:0;padding:0}}
</style>
</head>
<body>
@php
    $peran = session('peran');
    $labelPeran = ['guru' => 'Guru', 'kesiswaan' => 'Kesiswaan', 'kepsek' => 'Kepala Sekolah', 'admin' => 'Admin', 'ortu' => 'Orang tua'];
    $menuSekolah = [['Ringkasan sekolah', route('kesiswaan.dashboard')], ['Cari siswa', route('kesiswaan.cari')], ['Ganti password', route('akun.password')]];
    $menu = match ($peran) {
        'guru'      => [['Kelas saya', route('guru.dashboard')]],
        'kesiswaan', 'kepsek' => $menuSekolah,
        'admin'     => [['Pengguna', route('admin.pengguna')], ['Akun ortu massal', route('admin.massal')], ['Ringkasan sekolah', route('kesiswaan.dashboard')], ['Cari siswa', route('kesiswaan.cari')], ['Ganti password', route('akun.password')]],
        'ortu'      => [['Anak saya', route('ortu.dashboard')], ['Ganti password', route('akun.password')]],
        default     => [],
    };
    $sekarang = url()->current(); $aktif = null; $terpanjang = 0;
    foreach ($menu as $i => $m) { if (str_starts_with($sekarang, $m[1]) && strlen($m[1]) > $terpanjang) { $aktif = $i; $terpanjang = strlen($m[1]); } }
@endphp
@if($peran)
<aside class="side">
    <a href="{{ route('beranda') }}" class="logo">
        <img src="{{ asset('img/logo.png') }}" alt="">
        <span><b>Presensi Fingerprint</b><small>SMK Muhammadiyah 2 Metro</small></span>
    </a>
    <nav>
        @foreach($menu as $i => $m)
            <a href="{{ $m[1] }}" class="{{ $i === $aktif ? 'on' : '' }}">{{ $m[0] }}</a>
        @endforeach
    </nav>
</aside>
@endif
<div class="{{ $peran ? 'col' : '' }}">
    @if($peran)
    <header class="top">
        <span class="tt">@yield('title')</span>
        <a href="{{ route('beranda') }}" class="mob" style="text-decoration:none;color:inherit"><img src="{{ asset('img/logo.png') }}" alt="">Presensi</a>
        <form method="post" action="{{ route('logout') }}">
            @csrf
            <span class="who">{{ session('nama') }}<br><small>{{ $labelPeran[$peran] ?? $peran }}</small></span>
            <button type="submit" class="btn ghost">Keluar</button>
        </form>
    </header>
    @endif
    <main>
        @if(session('ok'))
            <div class="card flash">{{ session('ok') }}</div>
        @endif
        @yield('content')
    </main>
</div>
@if($peran)
<nav class="tabs">
    @foreach($menu as $i => $m)
        <a href="{{ $m[1] }}" class="{{ $i === $aktif ? 'on' : '' }}">{{ $m[0] }}</a>
    @endforeach
</nav>
@endif
</body>
</html>
