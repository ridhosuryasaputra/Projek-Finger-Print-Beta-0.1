@extends('layouts.app')
@section('title', 'Ringkasan Sekolah')

@section('content')
<h1>Ringkasan presensi seluruh sekolah</h1>
<p class="muted">{{ \Carbon\Carbon::parse($tanggal)->translatedFormat('l, j F Y') }}</p>

<form class="inline" method="get" action="{{ route('kesiswaan.dashboard') }}">
    <input type="date" name="tanggal" value="{{ $tanggal }}">
    <button type="submit">Tampilkan</button>
    <a class="btn ghost" href="{{ route('kesiswaan.cari') }}">Cari siswa</a>
</form>

<div class="kpis">
    <div class="kpi"><b>{{ $rekap['total']['total'] }}</b><span>Total siswa</span></div>
    <div class="kpi" style="--c:var(--ok)"><b class="ok">{{ $rekap['total']['hadir'] }}</b><span>Hadir</span></div>
    <div class="kpi" style="--c:var(--warn)"><b class="warn">{{ $rekap['total']['terlambat'] }}</b><span>Terlambat</span></div>
    <div class="kpi" style="--c:var(--bad)"><b class="bad">{{ $rekap['total']['belum_scan'] }}</b><span>Belum scan</span></div>
</div>

<div class="card">
    <div class="wrap">
        <table>
            <thead><tr><th>Kelas</th><th>Total</th><th>Hadir</th><th>Terlambat</th><th>Belum scan</th><th>Kehadiran</th></tr></thead>
            <tbody>
            @forelse($rekap['kelas'] as $k)
                @php $persen = $k->total ? round(($k->hadir + $k->terlambat) / $k->total * 100) : 0; @endphp
                <tr>
                    <td><a href="{{ route('kesiswaan.kelas', [$k->replid, 'tanggal' => $tanggal]) }}">{{ $k->kelas }}</a></td>
                    <td>{{ $k->total }}</td>
                    <td class="ok">{{ $k->hadir }}</td>
                    <td class="warn">{{ $k->terlambat }}</td>
                    <td class="bad">{{ $k->belum_scan }}</td>
                    <td style="min-width:130px"><div class="bar" title="{{ $persen }}%"><i style="width:{{ $persen }}%"></i></div><span class="muted">{{ $persen }}%</span></td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Belum ada kelas aktif di data JIBAS.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
