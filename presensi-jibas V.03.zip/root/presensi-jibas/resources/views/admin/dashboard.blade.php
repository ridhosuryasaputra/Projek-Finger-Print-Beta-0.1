@extends('layouts.app')
@section('title', 'Admin')

@section('content')
<h1>Akun aktif</h1>
<div class="kpis">
    @foreach(['admin' => 'Admin', 'kesiswaan' => 'Kesiswaan', 'kepsek' => 'Kepala sekolah', 'guru' => 'Guru lokal', 'ortu' => 'Orang tua'] as $kode => $nama)
        <div class="kpi"><b>{{ $hitung[$kode] ?? 0 }}</b><span>{{ $nama }}</span></div>
    @endforeach
</div>
<div class="card">
    <p>
        <a class="btn" href="{{ route('admin.pengguna') }}">Kelola pengguna</a>
        <a class="btn ghost" href="{{ route('admin.massal') }}">Buat akun orang tua per kelas</a>
        <a class="btn ghost" href="{{ route('kesiswaan.dashboard') }}">Ringkasan sekolah</a>
    </p>
    <p class="muted">Guru yang masuk dengan NIP dan password JIBAS tidak dikelola di sini.</p>
</div>
@endsection
