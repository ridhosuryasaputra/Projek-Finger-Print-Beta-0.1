<?php

namespace App\Http\Middleware;

use App\Services\AkunService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Membatasi akses berdasarkan peran di sesi: guru, kesiswaan, admin, ortu.
 * Pemakaian di route: Peran::class . ':admin,kesiswaan'
 */
class Peran
{
    public function __construct(private AkunService $akun)
    {
    }

    public function handle(Request $request, Closure $next, string ...$peran): Response
    {
        $sesi = $request->session();
        $sekarang = $sesi->get('peran');

        if (! $sekarang) {
            return redirect()->route('login');
        }

        // Akun lokal yang dinonaktifkan/dihapus admin langsung kehilangan akses.
        $uid = $sesi->get('user_id');
        if ($uid && ! $this->akun->masihAktif((int) $uid)) {
            $sesi->invalidate();

            return redirect()->route('login')->withErrors(['login' => 'Akun Anda tidak aktif.']);
        }

        if (! in_array($sekarang, $peran, true)) {
            abort(403, 'Anda tidak punya akses ke halaman ini.');
        }

        return $next($request);
    }
}
