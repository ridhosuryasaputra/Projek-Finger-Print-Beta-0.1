<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class GuruAuth
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->session()->has('guru_nip')) {
            return redirect()->route('login');
        }

        return $next($request);
    }
}
