<?php

namespace App\Http\Controllers;

use App\Services\AkunService;
use App\Services\PresensiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function form(Request $request)
    {
        if ($request->session()->has('peran')) {
            return redirect()->route('beranda');
        }

        return view('login');
    }

    /**
     * Urutan: akun lokal (admin, kesiswaan, orang tua) dulu, baru akun guru JIBAS.
     * Jika username ada di akun lokal tetapi password salah, TIDAK dilanjutkan ke JIBAS.
     */
    public function login(Request $request, PresensiService $presensi, AkunService $akun)
    {
        $data = $request->validate([
            'login'    => 'required|string|max:50',
            'password' => 'required|string|max:100',
        ]);

        $gagal = fn () => back()->withErrors(['login' => 'Login atau password salah.'])->onlyInput('login');

        $lokal = $akun->cari($data['login']);

        if ($lokal) {
            if (! $lokal->aktif || ! Hash::check($data['password'], $lokal->password)) {
                return $gagal();
            }

            $this->masuk($request, [
                'user_id' => (int) $lokal->id,
                'peran'   => $lokal->peran,
                'nama'    => $lokal->nama,
            ]);

            return redirect()->route('beranda');
        }

        try {
            $guru = $presensi->cekLogin($data['login'], $data['password']);
        } catch (\Throwable $e) {
            report($e);

            return back()
                ->withErrors(['login' => 'Database JIBAS tidak dapat dihubungi. Hubungi admin sekolah.'])
                ->onlyInput('login');
        }

        if (! $guru) {
            return $gagal();
        }

        $this->masuk($request, [
            'peran'     => 'guru',
            'guru_nip'  => $guru['nip'],
            'nama'      => $guru['nama'],
        ]);

        return redirect()->route('beranda');
    }

    public function logout(Request $request)
    {
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    private function masuk(Request $request, array $isi): void
    {
        $request->session()->regenerate();

        foreach ($isi as $kunci => $nilai) {
            $request->session()->put($kunci, $nilai);
        }
    }
}
