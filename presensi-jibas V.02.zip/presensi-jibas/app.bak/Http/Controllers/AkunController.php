<?php

namespace App\Http\Controllers;

use App\Services\AkunService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/** Ganti password sendiri untuk akun lokal (admin, kesiswaan, orang tua). Password guru dikelola di JIBAS. */
class AkunController extends Controller
{
    public function form()
    {
        return view('akun.password');
    }

    public function simpan(Request $request, AkunService $akun)
    {
        $data = $request->validate([
            'password_lama' => 'required|string',
            'password'      => 'required|string|min:8|max:100|confirmed',
        ]);

        $saya = $akun->find((int) $request->session()->get('user_id'));

        if (! $saya || ! Hash::check($data['password_lama'], $saya->password)) {
            return back()->withErrors(['password_lama' => 'Password lama salah.']);
        }

        $akun->ubah((int) $saya->id, [], $data['password']);

        return back()->with('ok', 'Password berhasil diganti.');
    }
}
