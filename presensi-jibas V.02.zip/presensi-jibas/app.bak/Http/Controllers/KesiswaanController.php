<?php

namespace App\Http\Controllers;

use App\Services\PresensiService;
use Illuminate\Http\Request;

/** Halaman untuk bagian kesiswaan (juga bisa dibuka admin): seluruh sekolah, semua kelas, semua siswa. */
class KesiswaanController extends Controller
{
    public function __construct(private PresensiService $presensi)
    {
    }

    private function hariIni(): string
    {
        return now(config('presensi.timezone'))->toDateString();
    }

    public function dashboard(Request $request)
    {
        $request->validate(['tanggal' => 'nullable|date_format:Y-m-d']);
        $tanggal = $request->query('tanggal', $this->hariIni());

        return view('kesiswaan.dashboard', [
            'tanggal' => $tanggal,
            'rekap'   => $this->presensi->rekapSekolahHarian($tanggal),
        ]);
    }

    public function kelas(Request $request, int $idkelas)
    {
        $kelas = $this->presensi->kelasById($idkelas);
        abort_unless($kelas, 404);

        $request->validate([
            'mode'    => 'nullable|in:harian,bulanan',
            'tanggal' => 'nullable|date_format:Y-m-d',
            'bulan'   => 'nullable|date_format:Y-m',
        ]);

        $mode = $request->query('mode', 'harian');
        $tanggal = $request->query('tanggal', $this->hariIni());
        $bulan = $request->query('bulan', now(config('presensi.timezone'))->format('Y-m'));

        $data = [
            'kelas' => $kelas, 'mode' => $mode, 'tanggal' => $tanggal, 'bulan' => $bulan,
            'rute' => 'kesiswaan.kelas', 'kembali' => route('kesiswaan.dashboard'), 'linkSiswa' => 'kesiswaan.siswa',
        ];

        if ($mode === 'bulanan') {
            $data['bulanan'] = $this->presensi->rekapBulanan($idkelas, $bulan);
        } else {
            $harian = $this->presensi->rekapHarian($idkelas, $tanggal);
            $data['harian'] = $harian;
            $data['ringkasan'] = $this->presensi->ringkasan($harian);
        }

        return view('guru.kelas', $data);
    }

    public function cari(Request $request)
    {
        $q = trim((string) $request->query('q', ''));
        $hasil = null;
        $pesan = null;

        if ($q !== '') {
            if (mb_strlen($q) < 2) {
                $pesan = 'Ketik minimal 2 huruf atau angka.';
            } else {
                $hasil = $this->presensi->cariSiswa($q);
            }
        }

        return view('kesiswaan.cari', ['q' => $q, 'hasil' => $hasil, 'pesan' => $pesan]);
    }

    public function siswa(Request $request, string $nis)
    {
        $siswa = $this->presensi->siswaByNis($nis);
        abort_unless($siswa, 404);

        $request->validate(['bulan' => 'nullable|date_format:Y-m']);
        $bulan = $request->query('bulan', now(config('presensi.timezone'))->format('Y-m'));

        return view('siswa.riwayat', [
            'siswa'   => $siswa,
            'riwayat' => $this->presensi->riwayatSiswa($nis, $bulan),
            'bulan'   => $bulan,
            'aksi'    => route('kesiswaan.siswa', $nis),
            'kembali' => route('kesiswaan.cari'),
        ]);
    }
}
