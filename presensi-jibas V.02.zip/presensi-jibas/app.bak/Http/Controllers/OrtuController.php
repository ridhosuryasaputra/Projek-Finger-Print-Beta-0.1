<?php

namespace App\Http\Controllers;

use App\Services\AkunService;
use App\Services\PresensiService;
use Illuminate\Http\Request;

/** Halaman orang tua: hanya siswa yang dihubungkan admin ke akun ini. */
class OrtuController extends Controller
{
    public function __construct(private PresensiService $presensi, private AkunService $akun)
    {
    }

    private function nisAnak(Request $request): array
    {
        return $this->akun->nisDari((int) $request->session()->get('user_id'));
    }

    public function dashboard(Request $request)
    {
        $siswa = $this->presensi->siswaByNisList($this->nisAnak($request));
        $hariIni = now(config('presensi.timezone'))->toDateString();

        return view('ortu.dashboard', [
            'siswa'   => $siswa,
            'status'  => $this->presensi->statusHari($siswa->pluck('nis')->map(fn ($n) => (string) $n)->all(), $hariIni),
            'hariIni' => $hariIni,
        ]);
    }

    public function anak(Request $request, string $nis)
    {
        // Pemeriksaan kepemilikan: orang tua tidak boleh membuka NIS yang bukan anaknya.
        abort_unless(in_array($nis, $this->nisAnak($request), true), 403, 'Siswa ini tidak terhubung dengan akun Anda.');

        $siswa = $this->presensi->siswaByNis($nis);
        abort_unless($siswa, 404);

        $request->validate(['bulan' => 'nullable|date_format:Y-m']);
        $bulan = $request->query('bulan', now(config('presensi.timezone'))->format('Y-m'));

        return view('siswa.riwayat', [
            'siswa'   => $siswa,
            'riwayat' => $this->presensi->riwayatSiswa($nis, $bulan),
            'bulan'   => $bulan,
            'aksi'    => route('ortu.anak', $nis),
            'kembali' => route('ortu.dashboard'),
        ]);
    }
}
