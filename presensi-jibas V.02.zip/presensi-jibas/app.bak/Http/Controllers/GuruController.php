<?php

namespace App\Http\Controllers;

use App\Services\PresensiService;
use Illuminate\Http\Request;

class GuruController extends Controller
{
    public function __construct(private PresensiService $presensi)
    {
    }

    public function dashboard(Request $request)
    {
        $nip = $request->session()->get('guru_nip');
        $hariIni = now(config('presensi.timezone'))->toDateString();

        $kelas = $this->presensi->kelasWali($nip)->map(function ($k) use ($hariIni) {
            $k->ringkasan = $this->presensi->ringkasan(
                $this->presensi->rekapHarian($k->replid, $hariIni)
            );

            return $k;
        });

        return view('guru.dashboard', ['kelas' => $kelas, 'hariIni' => $hariIni]);
    }

    public function kelas(Request $request, int $idkelas)
    {
        $nip = $request->session()->get('guru_nip');
        $kelas = $this->presensi->kelasMilik($nip, $idkelas);
        abort_unless($kelas, 403, 'Anda bukan wali kelas ini.');

        $request->validate([
            'mode'    => 'nullable|in:harian,bulanan',
            'tanggal' => 'nullable|date_format:Y-m-d',
            'bulan'   => 'nullable|date_format:Y-m',
        ]);

        $mode = $request->query('mode', 'harian');
        $sekarang = now(config('presensi.timezone'));
        $tanggal = $request->query('tanggal', $sekarang->toDateString());
        $bulan = $request->query('bulan', $sekarang->format('Y-m'));

        $data = ['kelas' => $kelas, 'mode' => $mode, 'tanggal' => $tanggal, 'bulan' => $bulan];

        if ($mode === 'bulanan') {
            $data['bulanan'] = $this->presensi->rekapBulanan($idkelas, $bulan);
        } else {
            $harian = $this->presensi->rekapHarian($idkelas, $tanggal);
            $data['harian'] = $harian;
            $data['ringkasan'] = $this->presensi->ringkasan($harian);
        }

        return view('guru.kelas', $data);
    }
}
