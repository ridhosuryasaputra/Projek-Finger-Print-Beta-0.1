<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BerandaController extends Controller
{
    /** Arahkan pengguna ke halaman utama sesuai perannya. */
    public function index(Request $request)
    {
        return match ($request->session()->get('peran')) {
            'guru'      => redirect()->route('guru.dashboard'),
            'kesiswaan' => redirect()->route('kesiswaan.dashboard'),
            'admin'     => redirect()->route('admin.dashboard'),
            'ortu'      => redirect()->route('ortu.dashboard'),
            default     => redirect()->route('login'),
        };
    }
}
