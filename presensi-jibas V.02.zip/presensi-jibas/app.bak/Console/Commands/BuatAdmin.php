<?php

namespace App\Console\Commands;

use App\Services\AkunService;
use Illuminate\Console\Command;

class BuatAdmin extends Command
{
    protected $signature = 'presensi:admin
                            {username : Nama pengguna (huruf, angka, titik, strip, garis bawah; 3-50 karakter)}
                            {--nama= : Nama lengkap}
                            {--peran=admin : admin atau kesiswaan}';

    protected $description = 'Buat akun admin/kesiswaan, atau reset password bila akunnya sudah ada';

    public function handle(AkunService $akun): int
    {
        $username = (string) $this->argument('username');
        $peran = (string) $this->option('peran');

        if (! preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username)) {
            $this->error('Username harus 3-50 karakter: huruf, angka, titik, strip, atau garis bawah.');

            return self::FAILURE;
        }

        if (! in_array($peran, ['admin', 'kesiswaan'], true)) {
            $this->error('Peran harus admin atau kesiswaan.');

            return self::FAILURE;
        }

        $password = (string) $this->secret('Password (minimal 8 karakter)');

        if (strlen($password) < 8) {
            $this->error('Password terlalu pendek.');

            return self::FAILURE;
        }

        if ($password !== (string) $this->secret('Ulangi password')) {
            $this->error('Password tidak sama.');

            return self::FAILURE;
        }

        $ada = $akun->cari($username);

        if ($ada) {
            $akun->ubah((int) $ada->id, ['aktif' => 1], $password);
            $this->info("Password akun '{$username}' diperbarui dan akun diaktifkan.");

            return self::SUCCESS;
        }

        $nama = (string) ($this->option('nama') ?: ucfirst($peran));
        $akun->buat($username, $nama, $peran, $password);
        $this->info("Akun {$peran} '{$username}' dibuat.");

        return self::SUCCESS;
    }
}
