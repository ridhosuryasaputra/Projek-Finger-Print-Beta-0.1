<?php

namespace App\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Akun lokal aplikasi (admin, kesiswaan, orang tua) di database SQLite aplikasi.
 * Guru tidak disimpan di sini: guru login dengan akun JIBAS.
 */
class AkunService
{
    public const PERAN = ['admin', 'kesiswaan', 'ortu'];

    public function cari(string $username): ?object
    {
        return DB::table('pengguna')->where('username', $username)->first();
    }

    public function find(int $id): ?object
    {
        return DB::table('pengguna')->where('id', $id)->first();
    }

    public function masihAktif(int $id): bool
    {
        return DB::table('pengguna')->where('id', $id)->where('aktif', 1)->exists();
    }

    public function buat(string $username, string $nama, string $peran, string $password, array $nis = []): int
    {
        $sekarang = now();

        $id = (int) DB::table('pengguna')->insertGetId([
            'username'   => $username,
            'password'   => $this->hash($password),
            'nama'       => $nama,
            'peran'      => $peran,
            'aktif'      => 1,
            'created_at' => $sekarang,
            'updated_at' => $sekarang,
        ]);

        $this->setNis($id, $nis);

        return $id;
    }

    /** Ubah kolom tertentu; password hanya diganti bila diisi. */
    public function ubah(int $id, array $data, ?string $password = null): void
    {
        $data['updated_at'] = now();

        if ($password !== null && $password !== '') {
            $data['password'] = $this->hash($password);
        }

        DB::table('pengguna')->where('id', $id)->update($data);
    }

    public function hapus(int $id): void
    {
        DB::table('ortu_siswa')->where('pengguna_id', $id)->delete();
        DB::table('pengguna')->where('id', $id)->delete();
    }

    /** @return string[] */
    public function nisDari(int $id): array
    {
        return DB::table('ortu_siswa')
            ->where('pengguna_id', $id)
            ->orderBy('nis')
            ->pluck('nis')
            ->map(fn ($n) => (string) $n)
            ->all();
    }

    public function setNis(int $id, array $nis): void
    {
        $nis = array_values(array_unique(array_filter(
            array_map(fn ($n) => trim((string) $n), $nis),
            fn ($n) => $n !== ''
        )));

        DB::table('ortu_siswa')->where('pengguna_id', $id)->delete();

        foreach ($nis as $n) {
            DB::table('ortu_siswa')->insert(['pengguna_id' => $id, 'nis' => $n]);
        }
    }

    /** Peta NIS => true untuk semua siswa yang sudah terhubung ke akun orang tua. */
    public function nisSudahPunyaAkun(): array
    {
        return DB::table('ortu_siswa')
            ->pluck('nis')
            ->map(fn ($n) => (string) $n)
            ->flip()
            ->all();
    }

    /** Daftar akun (maksimal 200 baris), lengkap dengan daftar NIS untuk orang tua. */
    public function daftar(?string $peran, ?string $q): Collection
    {
        $kueri = DB::table('pengguna')->orderBy('peran')->orderBy('nama');

        if ($peran) {
            $kueri->where('peran', $peran);
        }

        if ($q) {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $kueri->where(function ($w) use ($like) {
                $w->where('username', 'like', $like)->orWhere('nama', 'like', $like);
            });
        }

        $baris = $kueri->limit(200)->get();

        $nis = DB::table('ortu_siswa')
            ->whereIn('pengguna_id', $baris->pluck('id')->all())
            ->get()
            ->groupBy('pengguna_id');

        return $baris->map(function ($b) use ($nis) {
            $b->nis = $nis->get($b->id, collect())->pluck('nis')->map(fn ($n) => (string) $n)->all();

            return $b;
        });
    }

    /** Password acak 8 karakter tanpa huruf/angka yang mudah tertukar (0/O, 1/l/I). */
    public function passwordAcak(int $panjang = 8): string
    {
        $abjad = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $hasil = '';

        for ($i = 0; $i < $panjang; $i++) {
            $hasil .= $abjad[random_int(0, strlen($abjad) - 1)];
        }

        return $hasil;
    }

    private function hash(string $password): string
    {
        return Hash::make($password, ['rounds' => 10]);
    }
}
