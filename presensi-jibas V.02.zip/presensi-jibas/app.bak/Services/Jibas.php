<?php

namespace App\Services;

use Illuminate\Database\Connection;
use Illuminate\Support\Facades\DB;

/**
 * Akses read-only ke database JIBAS.
 * Koneksi didaftarkan saat dibutuhkan sehingga tidak perlu mengubah config/database.php.
 */
class Jibas
{
    public static function db(): Connection
    {
        if (! config('database.connections.jibas')) {
            config(['database.connections.jibas' => config('presensi.db')]);
        }

        return DB::connection('jibas');
    }

    /** Nama tabel lengkap dengan skema, mis. jbsakad.kelas */
    public static function t(string $schema, string $table): string
    {
        return config("presensi.schema.$schema") . '.' . $table;
    }
}
