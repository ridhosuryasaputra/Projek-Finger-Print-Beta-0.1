<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Collection;

class PresensiService
{
    /**
     * Cek login guru. Login JIBAS dianggap sama dengan NIP pegawai.
     * Mengembalikan ['nip' => ..., 'nama' => ...] atau null.
     */
    public function cekLogin(string $login, string $password): ?array
    {
        $user = Jibas::db()->table(Jibas::t('user', 'login'))
            ->where('login', $login)
            ->where('aktif', 1)
            ->first();

        if (! $user || ! $this->passwordCocok($password, (string) $user->password)) {
            return null;
        }

        $p = config('presensi.pegawai');
        $pegawai = Jibas::db()->table(Jibas::t('sdm', $p['table']))
            ->where($p['nip'], $login)
            ->first([$p['nip'] . ' as nip', $p['nama'] . ' as nama']);

        // Hanya pegawai (guru) yang boleh masuk.
        if (! $pegawai) {
            return null;
        }

        return ['nip' => $pegawai->nip, 'nama' => $pegawai->nama];
    }

    private function passwordCocok(string $input, string $tersimpan): bool
    {
        $hash = match (config('presensi.password_hash')) {
            'md5'   => md5($input),
            'sha1'  => sha1($input),
            default => $input,
        };

        return hash_equals(strtolower($tersimpan), strtolower($hash));
    }

    /** Kelas aktif yang diwalikan guru. */
    public function kelasWali(string $nip): Collection
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('nipwali', $nip)
            ->where('aktif', 1)
            ->orderBy('kelas')
            ->get(['replid', 'kelas']);
    }

    public function kelasMilik(string $nip, int $idkelas): ?object
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('replid', $idkelas)
            ->where('nipwali', $nip)
            ->first(['replid', 'kelas']);
    }

    public function siswaKelas(int $idkelas): Collection
    {
        $c = config('presensi.siswa');

        return Jibas::db()->table(Jibas::t('akad', $c['table']))
            ->where($c['kelas'], $idkelas)
            ->where($c['aktif'], 1)
            ->orderBy($c['nama'])
            ->get([$c['nis'] . ' as nis', $c['nama'] . ' as nama']);
    }

    /** Scan pertama (masuk) dan terakhir (pulang) per siswa per tanggal. */
    private function scanPerHari(array $nisList, string $dari, string $sampai): Collection
    {
        if (! $nisList) {
            return collect();
        }

        return Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->selectRaw('nis, DATE(jam) as tgl, MIN(jam) as masuk, MAX(jam) as pulang')
            ->whereIn('nis', $nisList)
            ->whereBetween('jam', ["$dari 00:00:00", "$sampai 23:59:59"])
            ->groupBy('nis', 'tgl')
            ->get();
    }

    private function terlambat(string $masuk): bool
    {
        $tanggal = substr($masuk, 0, 10);
        $batas = Carbon::parse($tanggal . ' ' . config('presensi.jam_masuk'))
            ->addMinutes(config('presensi.toleransi_menit'));

        return Carbon::parse($masuk)->gt($batas);
    }

    /**
     * Rekap satu hari. Status: hadir | terlambat | belum_scan.
     * Jika hanya ada satu scan, pulang = null.
     */
    public function rekapHarian(int $idkelas, string $tanggal): Collection
    {
        $siswa = $this->siswaKelas($idkelas);
        $scan = $this->scanPerHari($siswa->pluck('nis')->all(), $tanggal, $tanggal)->keyBy('nis');

        return $siswa->map(function ($s) use ($scan) {
            $r = $scan->get($s->nis);
            if (! $r) {
                return (object) ['nis' => $s->nis, 'nama' => $s->nama, 'masuk' => null, 'pulang' => null, 'status' => 'belum_scan'];
            }

            return (object) [
                'nis'    => $s->nis,
                'nama'   => $s->nama,
                'masuk'  => substr($r->masuk, 11, 5),
                'pulang' => $r->pulang !== $r->masuk ? substr($r->pulang, 11, 5) : null,
                'status' => $this->terlambat($r->masuk) ? 'terlambat' : 'hadir',
            ];
        });
    }

    public function ringkasan(Collection $rekapHarian): array
    {
        return [
            'total'      => $rekapHarian->count(),
            'hadir'      => $rekapHarian->where('status', 'hadir')->count(),
            'terlambat'  => $rekapHarian->where('status', 'terlambat')->count(),
            'belum_scan' => $rekapHarian->where('status', 'belum_scan')->count(),
        ];
    }

    /**
     * Rekap bulanan per siswa. "Hari sekolah" dihitung dari tanggal yang punya
     * minimal satu scan siswa mana pun di sekolah pada bulan itu.
     */
    public function rekapBulanan(int $idkelas, string $bulan): array
    {
        $awal = Carbon::createFromFormat('Y-m-d', $bulan . '-01')->startOfMonth();
        $dari = $awal->toDateString();
        $sampai = $awal->copy()->endOfMonth()->toDateString();

        $hariSekolah = Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->whereNotNull('nis')
            ->whereBetween('jam', ["$dari 00:00:00", "$sampai 23:59:59"])
            ->selectRaw('DATE(jam) as tgl')
            ->distinct()
            ->get()
            ->count();

        $siswa = $this->siswaKelas($idkelas);
        $scan = $this->scanPerHari($siswa->pluck('nis')->all(), $dari, $sampai)->groupBy('nis');

        $baris = $siswa->map(function ($s) use ($scan, $hariSekolah) {
            $hari = $scan->get($s->nis, collect());
            $telat = $hari->filter(fn ($h) => $this->terlambat($h->masuk))->count();
            $hadirTotal = $hari->count();

            return (object) [
                'nis'         => $s->nis,
                'nama'        => $s->nama,
                'hadir'       => $hadirTotal - $telat,
                'terlambat'   => $telat,
                'tidak_hadir' => max($hariSekolah - $hadirTotal, 0),
            ];
        });

        return ['hari_sekolah' => $hariSekolah, 'baris' => $baris];
    }

    /* ------------------------------------------------------------------
     * Tambahan untuk peran kesiswaan, admin, dan orang tua
     * ------------------------------------------------------------------ */

    public function semuaKelas(): Collection
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('aktif', 1)
            ->orderBy('kelas')
            ->get(['replid', 'kelas']);
    }

    public function kelasById(int $idkelas): ?object
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('replid', $idkelas)
            ->first(['replid', 'kelas']);
    }

    /** Apakah NIP/username ini sudah dipakai pegawai JIBAS (untuk mencegah bentrok dengan login guru). */
    public function pegawaiAda(string $nip): bool
    {
        $p = config('presensi.pegawai');

        return Jibas::db()->table(Jibas::t('sdm', $p['table']))->where($p['nip'], $nip)->exists();
    }

    /** Dasar query siswa + nama kelas: kolom nis, nama, kelas. */
    private function siswaQuery()
    {
        $c = config('presensi.siswa');

        return Jibas::db()->table(Jibas::t('akad', $c['table']) . ' as s')
            ->leftJoin(Jibas::t('akad', 'kelas') . ' as k', 's.' . $c['kelas'], '=', 'k.replid')
            ->select(['s.' . $c['nis'] . ' as nis', 's.' . $c['nama'] . ' as nama', 'k.kelas as kelas']);
    }

    public function siswaByNis(string $nis): ?object
    {
        $c = config('presensi.siswa');

        return $this->siswaQuery()->where('s.' . $c['nis'], $nis)->first();
    }

    public function siswaByNisList(array $nisList): Collection
    {
        if (! $nisList) {
            return collect();
        }

        $c = config('presensi.siswa');

        return $this->siswaQuery()
            ->whereIn('s.' . $c['nis'], $nisList)
            ->orderBy('s.' . $c['nama'])
            ->get();
    }

    /** Cari siswa aktif berdasarkan sebagian NIS atau nama (maksimal 30 hasil). */
    public function cariSiswa(string $q): Collection
    {
        $c = config('presensi.siswa');
        $like = '%' . addcslashes($q, '%_\\') . '%';

        return $this->siswaQuery()
            ->where('s.' . $c['aktif'], 1)
            ->where(function ($w) use ($c, $like) {
                $w->where('s.' . $c['nis'], 'like', $like)->orWhere('s.' . $c['nama'], 'like', $like);
            })
            ->orderBy('s.' . $c['nama'])
            ->limit(30)
            ->get();
    }

    /**
     * Ringkasan satu hari untuk seluruh sekolah, per kelas aktif.
     * Hanya dua query ke JIBAS (siswa aktif dan scan hari itu), sisanya dihitung di PHP.
     *
     * @return array{kelas: Collection, total: array<string,int>}
     */
    public function rekapSekolahHarian(string $tanggal): array
    {
        $c = config('presensi.siswa');

        $hasil = [];
        foreach ($this->semuaKelas() as $k) {
            $hasil[$k->replid] = (object) [
                'replid' => $k->replid, 'kelas' => $k->kelas,
                'total' => 0, 'hadir' => 0, 'terlambat' => 0, 'belum_scan' => 0,
            ];
        }

        $siswa = Jibas::db()->table(Jibas::t('akad', $c['table']))
            ->where($c['aktif'], 1)
            ->get([$c['nis'] . ' as nis', $c['kelas'] . ' as idkelas']);

        $scan = Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->selectRaw('nis, MIN(jam) as masuk')
            ->whereNotNull('nis')
            ->whereBetween('jam', ["$tanggal 00:00:00", "$tanggal 23:59:59"])
            ->groupBy('nis')
            ->get()
            ->keyBy('nis');

        $total = ['total' => 0, 'hadir' => 0, 'terlambat' => 0, 'belum_scan' => 0];

        foreach ($siswa as $s) {
            if (! isset($hasil[$s->idkelas])) {
                continue;
            }

            $r = $scan->get($s->nis);
            $status = ! $r ? 'belum_scan' : ($this->terlambat($r->masuk) ? 'terlambat' : 'hadir');

            $hasil[$s->idkelas]->total++;
            $hasil[$s->idkelas]->$status++;
            $total['total']++;
            $total[$status]++;
        }

        return ['kelas' => collect($hasil)->values(), 'total' => $total];
    }

    /** Daftar tanggal pada rentang itu yang punya minimal satu scan siswa mana pun ("hari sekolah"). */
    private function hariSekolah(string $dari, string $sampai): array
    {
        return Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->selectRaw('DATE(jam) as tgl')
            ->whereNotNull('nis')
            ->whereBetween('jam', ["$dari 00:00:00", "$sampai 23:59:59"])
            ->groupBy('tgl')
            ->orderBy('tgl')
            ->pluck('tgl')
            ->all();
    }

    /**
     * Riwayat satu siswa dalam satu bulan (format Y-m), hanya pada hari sekolah.
     * Hari ini yang belum ada scan ditandai "belum_scan", bukan "tidak_hadir".
     */
    public function riwayatSiswa(string $nis, string $bulan): array
    {
        $tz = config('presensi.timezone');
        $awal = Carbon::createFromFormat('Y-m-d', $bulan . '-01', $tz)->startOfMonth();
        $dari = $awal->toDateString();
        $sampai = $awal->copy()->endOfMonth()->toDateString();
        $hariIni = now($tz)->toDateString();

        $scan = $this->scanPerHari([$nis], $dari, $sampai)->keyBy('tgl');

        $baris = collect($this->hariSekolah($dari, $sampai))->map(function ($tgl) use ($scan, $hariIni) {
            $r = $scan->get($tgl);

            if (! $r) {
                return (object) [
                    'tgl' => $tgl, 'masuk' => null, 'pulang' => null,
                    'status' => $tgl === $hariIni ? 'belum_scan' : 'tidak_hadir',
                ];
            }

            return (object) [
                'tgl'    => $tgl,
                'masuk'  => substr($r->masuk, 11, 5),
                'pulang' => $r->pulang !== $r->masuk ? substr($r->pulang, 11, 5) : null,
                'status' => $this->terlambat($r->masuk) ? 'terlambat' : 'hadir',
            ];
        })->values();

        return [
            'baris'       => $baris,
            'hadir'       => $baris->where('status', 'hadir')->count(),
            'terlambat'   => $baris->where('status', 'terlambat')->count(),
            'tidak_hadir' => $baris->where('status', 'tidak_hadir')->count(),
        ];
    }

    /**
     * Status satu hari untuk beberapa siswa sekaligus.
     *
     * @param  string[] $nisList
     * @return array<string, object>  NIS => {masuk, pulang, status}
     */
    public function statusHari(array $nisList, string $tanggal): array
    {
        $scan = $this->scanPerHari($nisList, $tanggal, $tanggal)->keyBy('nis');
        $hasil = [];

        foreach ($nisList as $nis) {
            $r = $scan->get($nis);

            $hasil[$nis] = $r
                ? (object) [
                    'masuk'  => substr($r->masuk, 11, 5),
                    'pulang' => $r->pulang !== $r->masuk ? substr($r->pulang, 11, 5) : null,
                    'status' => $this->terlambat($r->masuk) ? 'terlambat' : 'hadir',
                ]
                : (object) ['masuk' => null, 'pulang' => null, 'status' => 'belum_scan'];
        }

        return $hasil;
    }
}
