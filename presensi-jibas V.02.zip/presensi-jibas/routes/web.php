<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AkunController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BerandaController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\KesiswaanController;
use App\Http\Controllers\OrtuController;
use App\Http\Middleware\Peran;
use Illuminate\Support\Facades\Route;

Route::get('/', [BerandaController::class, 'index'])->name('beranda');

Route::get('/login', [AuthController::class, 'form'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Guru: hanya kelas yang diwalikan
Route::middleware(Peran::class . ':guru')->prefix('guru')->group(function () {
    Route::get('/', [GuruController::class, 'dashboard'])->name('guru.dashboard');
    Route::get('/kelas/{idkelas}', [GuruController::class, 'kelas'])
        ->whereNumber('idkelas')
        ->name('guru.kelas');
});

// Kesiswaan (dan admin): seluruh sekolah
Route::middleware(Peran::class . ':kesiswaan,kepsek,admin')->prefix('kesiswaan')->group(function () {
    Route::get('/', [KesiswaanController::class, 'dashboard'])->name('kesiswaan.dashboard');
    Route::get('/kelas/{idkelas}', [KesiswaanController::class, 'kelas'])
        ->whereNumber('idkelas')
        ->name('kesiswaan.kelas');
    Route::get('/siswa', [KesiswaanController::class, 'cari'])->name('kesiswaan.cari');
    Route::get('/siswa/{nis}', [KesiswaanController::class, 'siswa'])
        ->where('nis', '[A-Za-z0-9._-]+')
        ->name('kesiswaan.siswa');
});

// Orang tua: hanya anak yang dihubungkan ke akunnya
Route::middleware(Peran::class . ':ortu')->prefix('ortu')->group(function () {
    Route::get('/', [OrtuController::class, 'dashboard'])->name('ortu.dashboard');
    Route::get('/anak/{nis}', [OrtuController::class, 'anak'])
        ->where('nis', '[A-Za-z0-9._-]+')
        ->name('ortu.anak');
});

// Admin: kelola akun
Route::middleware(Peran::class . ':admin')->prefix('admin')->group(function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('admin.dashboard');

    Route::get('/pengguna', [AdminController::class, 'pengguna'])->name('admin.pengguna');
    Route::get('/pengguna/buat', [AdminController::class, 'buat'])->name('admin.pengguna.buat');
    Route::post('/pengguna', [AdminController::class, 'simpan'])->name('admin.pengguna.simpan');
    Route::get('/pengguna/{id}/ubah', [AdminController::class, 'ubah'])->whereNumber('id')->name('admin.pengguna.ubah');
    Route::put('/pengguna/{id}', [AdminController::class, 'perbarui'])->whereNumber('id')->name('admin.pengguna.perbarui');
    Route::delete('/pengguna/{id}', [AdminController::class, 'hapus'])->whereNumber('id')->name('admin.pengguna.hapus');

    Route::get('/ortu-massal', [AdminController::class, 'massal'])->name('admin.massal');
    Route::post('/ortu-massal', [AdminController::class, 'massalProses'])->name('admin.massal.proses');
});

// Ganti password sendiri (akun lokal)
Route::middleware(Peran::class . ':admin,kesiswaan,kepsek,ortu')->group(function () {
    Route::get('/akun/password', [AkunController::class, 'form'])->name('akun.password');
    Route::post('/akun/password', [AkunController::class, 'simpan']);
});
