-- DATA CONTOH untuk uji coba aplikasi. JANGAN dijalankan di server JIBAS produksi
-- kecuali Anda paham: skema yang dibuat memakai awalan demo_ sehingga tidak
-- menimpa jbsakad/jbssdm/jbsumum/jbsuser, tetapi sebaiknya tetap dijalankan di
-- MySQL/MariaDB terpisah (mis. XAMPP di laptop).
--
-- Login uji coba: NIP 198501012010011001 / password guru123  (JIBAS_PASSWORD_HASH=md5)
-- Isi .env:  JIBAS_DB_AKAD=demo_jbsakad  JIBAS_DB_SDM=demo_jbssdm
--            JIBAS_DB_UMUM=demo_jbsumum  JIBAS_DB_USER=demo_jbsuser

CREATE DATABASE IF NOT EXISTS demo_jbsakad  CHARACTER SET utf8mb4;
CREATE DATABASE IF NOT EXISTS demo_jbssdm   CHARACTER SET utf8mb4;
CREATE DATABASE IF NOT EXISTS demo_jbsumum  CHARACTER SET utf8mb4;
CREATE DATABASE IF NOT EXISTS demo_jbsuser  CHARACTER SET utf8mb4;

DROP TABLE IF EXISTS demo_jbsuser.login;
CREATE TABLE demo_jbsuser.login (
  replid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  login VARCHAR(30) NOT NULL,
  password VARCHAR(100) NOT NULL,
  aktif TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
);
INSERT INTO demo_jbsuser.login (login, password, aktif)
VALUES ('198501012010011001', MD5('guru123'), 1);

DROP TABLE IF EXISTS demo_jbssdm.pegawai;
CREATE TABLE demo_jbssdm.pegawai (
  replid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nip VARCHAR(30) NOT NULL,
  nama VARCHAR(100) NOT NULL
);
INSERT INTO demo_jbssdm.pegawai (nip, nama) VALUES ('198501012010011001', 'Guru Contoh, S.Kom');

DROP TABLE IF EXISTS demo_jbsakad.kelas;
CREATE TABLE demo_jbsakad.kelas (
  replid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  kelas VARCHAR(50) NOT NULL,
  nipwali VARCHAR(30) NOT NULL,
  aktif TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
);
INSERT INTO demo_jbsakad.kelas (kelas, nipwali, aktif) VALUES ('X TJKT 1', '198501012010011001', 1);

DROP TABLE IF EXISTS demo_jbsakad.siswa;
CREATE TABLE demo_jbsakad.siswa (
  replid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nis VARCHAR(20) NOT NULL,
  nama VARCHAR(100) NOT NULL,
  idkelas INT UNSIGNED NOT NULL,
  aktif TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
);
INSERT INTO demo_jbsakad.siswa (nis, nama, idkelas, aktif) VALUES
 ('260001', 'Ahmad Fauzi', 1, 1),
 ('260002', 'Bella Safitri', 1, 1),
 ('260003', 'Candra Wijaya', 1, 1),
 ('260004', 'Dewi Lestari', 1, 1),
 ('260005', 'Eko Prasetyo', 1, 1),
 ('260006', 'Fitri Handayani', 1, 1),
 ('260007', 'Gilang Ramadhan', 1, 1),
 ('260008', 'Hana Permata', 1, 1);

DROP TABLE IF EXISTS demo_jbsumum.cardscandata;
CREATE TABLE demo_jbsumum.cardscandata (
  replid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  idscaninfo INT UNSIGNED NOT NULL DEFAULT 1,
  nis VARCHAR(20) NULL,
  nip VARCHAR(30) NULL,
  nic VARCHAR(20) NULL,
  jam DATETIME NOT NULL,
  keterangan VARCHAR(255) NOT NULL DEFAULT '',
  KEY (nis), KEY (jam)
);

-- Scan masuk 5 hari terakhir (hari kerja saja). Jam masuk 06:30-07:19, sebagian terlambat.
-- Sebagian siswa sengaja tidak scan pada hari tertentu.
INSERT INTO demo_jbsumum.cardscandata (nis, jam)
SELECT s.nis,
       TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL d.n DAY),
                 SEC_TO_TIME(23400 + ((CAST(RIGHT(s.nis, 2) AS UNSIGNED) * 7 + d.n * 3) % 50) * 60))
FROM demo_jbsakad.siswa s
CROSS JOIN (SELECT 0 n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) d
WHERE DAYOFWEEK(DATE_SUB(CURDATE(), INTERVAL d.n DAY)) NOT IN (1, 7)
  AND (CAST(RIGHT(s.nis, 2) AS UNSIGNED) + d.n) % 7 <> 0;

-- Scan pulang sekitar 15:00-15:39 untuk hari yang sudah lewat (bukan hari ini)
INSERT INTO demo_jbsumum.cardscandata (nis, jam)
SELECT s.nis,
       TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL d.n DAY),
                 SEC_TO_TIME(54000 + ((CAST(RIGHT(s.nis, 2) AS UNSIGNED) * 11 + d.n) % 40) * 60))
FROM demo_jbsakad.siswa s
CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) d
WHERE DAYOFWEEK(DATE_SUB(CURDATE(), INTERVAL d.n DAY)) NOT IN (1, 7)
  AND (CAST(RIGHT(s.nis, 2) AS UNSIGNED) + d.n) % 7 <> 0;
