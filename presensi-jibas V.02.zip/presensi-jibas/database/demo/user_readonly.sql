-- Jalankan sebagai root di MySQL/MariaDB server JIBAS.
-- Membuat user khusus yang HANYA bisa membaca (SELECT) tabel yang dibutuhkan aplikasi.
-- Ganti 'GANTI_PASSWORD_KUAT' dan, bila aplikasi berjalan di komputer lain, ganti 'localhost'.

CREATE USER IF NOT EXISTS 'presensi_ro'@'localhost' IDENTIFIED BY 'GANTI_PASSWORD_KUAT';

GRANT SELECT ON jbsakad.kelas         TO 'presensi_ro'@'localhost';
GRANT SELECT ON jbsakad.siswa         TO 'presensi_ro'@'localhost';
GRANT SELECT ON jbssdm.pegawai        TO 'presensi_ro'@'localhost';
GRANT SELECT ON jbsumum.cardscandata  TO 'presensi_ro'@'localhost';
GRANT SELECT ON jbsuser.login         TO 'presensi_ro'@'localhost';

FLUSH PRIVILEGES;
