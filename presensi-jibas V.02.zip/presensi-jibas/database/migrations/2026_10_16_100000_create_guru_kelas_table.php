<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 * Penugasan guru ke kelas yang diatur admin. Disimpan di SQLite aplikasi,
 * TANPA foreign key ke JIBAS (NIP dan ID kelas hanya berupa nilai).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('guru_kelas', function (Blueprint $t) {
            $t->id();
            $t->string('nip', 30);
            $t->unsignedInteger('idkelas');
            $t->unique(['nip', 'idkelas']);
            $t->index('idkelas');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('guru_kelas');
    }
};
