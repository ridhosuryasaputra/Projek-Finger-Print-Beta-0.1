<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 * Akun lokal aplikasi: admin, kesiswaan, orang tua.
 * Disimpan di database aplikasi sendiri (SQLite), BUKAN di database JIBAS.
 * Guru tidak ada di sini karena guru login dengan akun JIBAS.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pengguna', function (Blueprint $t) {
            $t->id();
            $t->string('username', 50)->unique();
            $t->string('password');
            $t->string('nama', 100);
            $t->string('peran', 20); // admin | kesiswaan | ortu
            $t->boolean('aktif')->default(true);
            $t->timestamps();
        });

        Schema::create('ortu_siswa', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('pengguna_id');
            $t->string('nis', 20);
            $t->unique(['pengguna_id', 'nis']);
            $t->index('nis');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ortu_siswa');
        Schema::dropIfExists('pengguna');
    }
};
