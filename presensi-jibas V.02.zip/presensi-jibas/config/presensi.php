<?php

/*
 * Pengaturan aplikasi Presensi Fingerprint (membaca database JIBAS).
 * Semua nilai bisa diubah lewat file .env. Nama tabel/kolom JIBAS
 * dikumpulkan di sini supaya mudah disesuaikan tanpa mengubah kode.
 */

return [

    // Koneksi ke database JIBAS. GUNAKAN USER MYSQL KHUSUS DENGAN HAK SELECT SAJA.
    'db' => [
        'driver'    => 'mysql',
        'host'      => env('JIBAS_DB_HOST', '127.0.0.1'),
        'port'      => env('JIBAS_DB_PORT', '3306'),
        'database'  => env('JIBAS_DB_AKAD', 'jbsakad'),
        'username'  => env('JIBAS_DB_USERNAME', 'presensi_ro'),
        'password'  => env('JIBAS_DB_PASSWORD', ''),
        'charset'   => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix'    => '',
        'strict'    => false,
    ],

    // Nama skema (database) JIBAS. Ubah hanya jika memakai data contoh (demo_*).
    'schema' => [
        'akad' => env('JIBAS_DB_AKAD', 'jbsakad'),
        'sdm'  => env('JIBAS_DB_SDM', 'jbssdm'),
        'umum' => env('JIBAS_DB_UMUM', 'jbsumum'),
        'user' => env('JIBAS_DB_USER', 'jbsuser'),
    ],

    // Cara JIBAS menyimpan password di jbsuser.login: md5 | sha1 | plain
    // PERLU DIVERIFIKASI di server Anda (lihat README).
    'password_hash' => env('JIBAS_PASSWORD_HASH', 'md5'),

    // Zona waktu untuk menentukan "hari ini" (Laravel 11/12 tidak membaca APP_TIMEZONE dari .env)
    'timezone' => env('PRESENSI_TIMEZONE', 'Asia/Jakarta'),

    // Aturan keterlambatan
    'jam_masuk'       => env('PRESENSI_JAM_MASUK', '07:00'),
    'toleransi_menit' => (int) env('PRESENSI_TOLERANSI', 0),

    // Pemetaan tabel/kolom JIBAS. PERLU DIVERIFIKASI dengan DESCRIBE (lihat README).
    'siswa' => [
        'table' => 'siswa',   // jbsakad.siswa
        'nis'   => 'nis',
        'nama'  => 'nama',
        'kelas' => 'idkelas',
        'aktif' => 'aktif',
    ],
    'pegawai' => [
        'table' => 'pegawai', // jbssdm.pegawai
        'nip'   => 'nip',
        'nama'  => 'nama',
    ],
];
