<?php

namespace App\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/** Penugasan guru ke kelas (tabel lokal guru_kelas, tidak menyentuh database JIBAS). */
class GuruKelasService
{
    /** Kunci penugasan untuk akun guru lokal (bukan NIP, supaya tidak bentrok dengan JIBAS). */
    public static function kunci(int $idAkun): string
    {
        return 'U' . $idAkun;
    }

    /** @return int[] */
    public function idKelasDari(string $nip): array
    {
        return DB::table('guru_kelas')
            ->where('nip', $nip)
            ->pluck('idkelas')
            ->map(fn ($i) => (int) $i)
            ->all();
    }

    /** NIP => daftar ID kelas, untuk halaman admin. */
    public function semua(): Collection
    {
        return DB::table('guru_kelas')->orderBy('nip')->get()->groupBy('nip')
            ->map(fn ($baris) => $baris->pluck('idkelas')->map(fn ($i) => (int) $i)->all());
    }

    /** Ganti seluruh penugasan satu guru. */
    public function set(string $nip, array $idKelas): void
    {
        $idKelas = array_values(array_unique(array_filter(array_map('intval', $idKelas))));

        DB::transaction(function () use ($nip, $idKelas) {
            DB::table('guru_kelas')->where('nip', $nip)->delete();

            foreach ($idKelas as $id) {
                DB::table('guru_kelas')->insert(['nip' => $nip, 'idkelas' => $id]);
            }
        });
    }
}
