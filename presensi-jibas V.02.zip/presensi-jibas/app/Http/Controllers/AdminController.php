<?php

namespace App\Http\Controllers;

use App\Services\AkunService;
use App\Services\GuruKelasService;
use App\Services\PresensiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function __construct(private AkunService $akun, private PresensiService $presensi, private GuruKelasService $guruKelas)
    {
    }

    public function dashboard()
    {
        $hitung = DB::table('pengguna')
            ->selectRaw('peran, COUNT(*) as n')
            ->where('aktif', 1)
            ->groupBy('peran')
            ->pluck('n', 'peran');

        return view('admin.dashboard', ['hitung' => $hitung]);
    }

    public function pengguna(Request $request)
    {
        $peran = $request->query('peran');
        if (! in_array($peran, AkunService::PERAN, true)) {
            $peran = null;
        }

        $q = trim((string) $request->query('q', ''));

        return view('admin.pengguna', [
            'daftar' => $this->akun->daftar($peran, $q),
            'peran'  => $peran,
            'q'      => $q,
        ]);
    }

    public function buat()
    {
        return view('admin.form', [
            'p' => null, 'nis' => '', 'siswa' => collect(),
            'kelas' => $this->daftarKelas(), 'kelasDipilih' => [],
            'aksi' => route('admin.pengguna.simpan'), 'metode' => 'POST',
        ]);
    }

    public function simpan(Request $request)
    {
        $data = $request->validate([
            'username' => ['required', 'regex:/^[A-Za-z0-9_.-]{3,50}$/', 'unique:pengguna,username'],
            'nama'     => 'required|string|max:100',
            'peran'    => 'required|in:admin,kesiswaan,kepsek,guru,ortu',
            'kelas'    => 'nullable|array',
            'kelas.*'  => 'integer',
            'password' => 'required|string|min:8|max:100',
            'nis'      => 'nullable|string|max:2000',
        ], [
            'username.regex'  => 'Username 3-50 karakter: huruf, angka, titik, strip, atau garis bawah.',
            'username.unique' => 'Username ini sudah dipakai.',
        ]);

        // Hindari bentrok dengan login guru: akun lokal selalu diperiksa lebih dulu daripada JIBAS.
        try {
            if ($this->presensi->pegawaiAda($data['username'])) {
                return back()->withErrors(['username' => 'Username ini sama dengan NIP pegawai JIBAS; pilih username lain agar login guru tidak terganggu.'])->withInput();
            }
        } catch (\Throwable $e) {
            report($e);
        }

        $nis = $data['peran'] === 'ortu' ? $this->parseNis($data['nis'] ?? '') : [];

        if ($galat = $this->cekNis($nis)) {
            return back()->withErrors(['nis' => $galat])->withInput();
        }

        $id = $this->akun->buat($data['username'], $data['nama'], $data['peran'], $data['password'], $nis);
        $this->simpanKelas($id, $data['peran'], (array) $request->input('kelas', []));

        return redirect()->route('admin.pengguna')->with('ok', 'Akun dibuat.');
    }

    public function ubah(int $id)
    {
        $p = $this->akun->find($id);
        abort_unless($p, 404);

        $nisList = $this->akun->nisDari($id);

        try {
            $siswa = $this->presensi->siswaByNisList($nisList);
        } catch (\Throwable $e) {
            report($e);
            $siswa = collect();
        }

        return view('admin.form', [
            'p' => $p, 'nis' => implode("\n", $nisList), 'siswa' => $siswa,
            'kelas' => $this->daftarKelas(),
            'kelasDipilih' => $this->guruKelas->idKelasDari(GuruKelasService::kunci($id)),
            'aksi' => route('admin.pengguna.perbarui', $id), 'metode' => 'PUT',
        ]);
    }

    public function perbarui(Request $request, int $id)
    {
        $p = $this->akun->find($id);
        abort_unless($p, 404);

        $data = $request->validate([
            'nama'     => 'required|string|max:100',
            'peran'    => 'required|in:admin,kesiswaan,kepsek,guru,ortu',
            'kelas'    => 'nullable|array',
            'kelas.*'  => 'integer',
            'password' => 'nullable|string|min:8|max:100',
            'nis'      => 'nullable|string|max:2000',
        ]);

        $aktif = $request->boolean('aktif');

        // Cegah admin mengunci dirinya sendiri.
        if ($id === (int) $request->session()->get('user_id') && (! $aktif || $data['peran'] !== $p->peran)) {
            return back()->withErrors(['nama' => 'Anda tidak dapat menonaktifkan atau mengubah peran akun Anda sendiri.'])->withInput();
        }

        $nis = $data['peran'] === 'ortu' ? $this->parseNis($data['nis'] ?? '') : [];

        if ($galat = $this->cekNis($nis)) {
            return back()->withErrors(['nis' => $galat])->withInput();
        }

        $this->akun->ubah($id, [
            'nama'  => $data['nama'],
            'peran' => $data['peran'],
            'aktif' => $aktif ? 1 : 0,
        ], $data['password'] ?? null);

        $this->akun->setNis($id, $nis);
        $this->simpanKelas($id, $data['peran'], (array) $request->input('kelas', []));

        return redirect()->route('admin.pengguna')->with('ok', 'Akun diperbarui.');
    }

    public function hapus(Request $request, int $id)
    {
        if ($id === (int) $request->session()->get('user_id')) {
            return back()->withErrors(['hapus' => 'Anda tidak dapat menghapus akun Anda sendiri.']);
        }

        $this->akun->hapus($id);

        return redirect()->route('admin.pengguna')->with('ok', 'Akun dihapus.');
    }

    public function massal()
    {
        try {
            $kelas = $this->presensi->semuaKelas();
            $galat = null;
        } catch (\Throwable $e) {
            report($e);
            $kelas = collect();
            $galat = 'Database JIBAS tidak dapat dihubungi, daftar kelas tidak tersedia.';
        }

        return view('admin.massal', ['kelas' => $kelas, 'galat' => $galat]);
    }

    /**
     * Buat satu akun orang tua per siswa aktif di kelas yang dipilih.
     * Username: "ortu" + NIS. Password acak ditampilkan SEKALI di halaman hasil.
     */
    public function massalProses(Request $request)
    {
        $data = $request->validate(['idkelas' => 'required|integer']);

        $kelas = $this->presensi->kelasById((int) $data['idkelas']);
        abort_unless($kelas, 404);

        $sudah = $this->akun->nisSudahPunyaAkun();
        $baru = [];
        $dilewati = [];

        foreach ($this->presensi->siswaKelas((int) $kelas->replid) as $s) {
            $nis = (string) $s->nis;

            if (isset($sudah[$nis])) {
                $dilewati[] = (object) ['nis' => $nis, 'nama' => $s->nama, 'alasan' => 'sudah punya akun orang tua'];
                continue;
            }

            $username = 'ortu' . preg_replace('/[^A-Za-z0-9_-]/', '', $nis);

            if ($username === 'ortu' || $this->akun->cari($username)) {
                $dilewati[] = (object) ['nis' => $nis, 'nama' => $s->nama, 'alasan' => 'username sudah dipakai'];
                continue;
            }

            $password = $this->akun->passwordAcak();
            $this->akun->buat($username, mb_substr('Orang tua ' . $s->nama, 0, 100), 'ortu', $password, [$nis]);

            $baru[] = (object) ['nis' => $nis, 'nama' => $s->nama, 'username' => $username, 'password' => $password];
        }

        return view('admin.massal-hasil', ['kelas' => $kelas, 'baru' => $baru, 'dilewati' => $dilewati]);
    }

    private function daftarKelas()
    {
        try {
            return $this->presensi->semuaKelas();
        } catch (\Throwable $e) {
            report($e);

            return collect();
        }
    }

    /** Simpan kelas yang diwalikan akun guru; peran lain otomatis dikosongkan. */
    private function simpanKelas(int $id, string $peran, array $kelas): void
    {
        $kunci = GuruKelasService::kunci($id);

        if ($peran !== 'guru') {
            $this->guruKelas->set($kunci, []);

            return;
        }

        $valid = $this->daftarKelas()->pluck('replid')->map(fn ($i) => (int) $i)->all();

        if (! $valid) {
            return; // JIBAS tidak terjangkau: jangan menghapus penugasan yang ada
        }

        $this->guruKelas->set($kunci, array_values(array_intersect(array_map('intval', $kelas), $valid)));
    }

    /** @return string[] */
    private function parseNis(string $teks): array
    {
        return array_values(array_unique(preg_split('/[\s,;]+/', trim($teks), -1, PREG_SPLIT_NO_EMPTY) ?: []));
    }

    /** Pastikan semua NIS ada di JIBAS. Mengembalikan pesan galat, atau null bila semuanya valid. */
    private function cekNis(array $nis): ?string
    {
        if (! $nis) {
            return null;
        }

        try {
            $ada = $this->presensi->siswaByNisList($nis)->pluck('nis')->map(fn ($n) => (string) $n)->all();
        } catch (\Throwable $e) {
            report($e);

            return 'Database JIBAS tidak dapat dihubungi, NIS belum bisa diperiksa.';
        }

        $tidak = array_values(array_diff($nis, $ada));

        return $tidak ? 'NIS tidak ditemukan di JIBAS: ' . implode(', ', $tidak) : null;
    }
}
