# Presensi Fingerprint (Laravel)

Aplikasi web **read-only** untuk menampilkan hasil presensi fingerprint dari database JIBAS.
Data presensi dan siswa dibaca dari JIBAS; JIBAS tidak pernah ditulis. Akun admin, kesiswaan,
dan orang tua disimpan terpisah di SQLite milik aplikasi.

Status: semua file PHP lolos `php -l` dan template Blade diperiksa keseimbangannya. **Peran guru sudah
berjalan di VM uji; peran kesiswaan, admin, dan orang tua belum pernah dijalankan**, jadi uji dulu dengan
data contoh (lihat "Uji coba").

## Peran

| Peran | Login | Yang bisa dilihat |
|---|---|---|
| Guru | NIP + password JIBAS | Kelas yang diwalikannya (harian, bulanan) |
| Kesiswaan | Akun lokal | Ringkasan seluruh sekolah, semua kelas, cari siswa, riwayat siswa |
| Admin | Akun lokal | Semua halaman kesiswaan + kelola akun + buat akun orang tua per kelas |
| Orang tua | Akun lokal | Hanya anak yang dihubungkan admin ke akunnya |

Login memeriksa akun lokal dulu, baru JIBAS. Karena itu admin tidak bisa membuat username yang sama
dengan NIP pegawai JIBAS (aplikasi menolaknya).

## Pemasangan baru (Debian 12 / LXC)
1. Salin folder ini ke server, mis. `/root/presensi-jibas`.
2. `bash deploy/install-lxc.sh` (sebagai root). Skrip menanyakan domain, koneksi database JIBAS, HTTPS,
   lalu membuat akun admin pertama.

## Memperbarui yang sudah terpasang
```bash
cd /root/presensi-jibas && bash deploy/update.sh
```
Skrip menyalin kode, menyiapkan SQLite, menjalankan migrasi, dan menyegarkan cache. `.env` dan pengaturan
JIBAS tidak ditimpa. Buat admin pertama bila belum ada:
```bash
cd /var/www/presensi
runuser -u www-data -- php artisan presensi:admin NAMAADMIN --nama="Administrator"
# untuk akun kesiswaan: tambahkan --peran=kesiswaan
```
Jalankan perintah `artisan` sebagai `www-data` (bukan root) agar file SQLite tidak berpindah pemilik.

## Alur akun orang tua
1. Admin masuk, buka **Akun orang tua massal**, pilih kelas. Sistem membuat akun `ortu<NIS>` dengan password
   acak untuk setiap siswa aktif, dan menampilkannya **sekali** untuk dicetak.
2. Bagikan username dan password ke orang tua; minta mereka mengganti password lewat menu **Ganti password**.
3. Orang tua dengan dua anak: tambahkan NIS anak kedua ke salah satu akun lewat **Pengguna > Ubah**.

## Uji coba dengan data contoh
`database/demo/demo_jibas.sql` membuat skema `demo_*` (satu kelas, 8 siswa, scan 5 hari terakhir).
Arahkan `.env` ke skema itu (`JIBAS_DB_AKAD=demo_jbsakad`, `JIBAS_DB_SDM=demo_jbssdm`,
`JIBAS_DB_UMUM=demo_jbsumum`, `JIBAS_DB_USER=demo_jbsuser`), lalu `php artisan config:cache`.
Login guru contoh: `198501012010011001` / `guru123`. Buat admin dengan perintah di atas, lalu coba
alur orang tua.

## Asumsi yang HARUS diverifikasi di server JIBAS asli
| Asumsi | Cek |
|---|---|
| Password di `jbsuser.login` berupa MD5 | `SELECT login, password FROM jbsuser.login LIMIT 3;` (MD5 = 32 karakter hex) |
| `login` guru = NIP di `jbssdm.pegawai` | `SELECT nip, nama FROM jbssdm.pegawai LIMIT 5;` |
| Tabel siswa: kolom `nis`, `nama`, `idkelas`, `aktif` | `DESCRIBE jbsakad.siswa;` |
| Tabel pegawai: kolom `nip`, `nama` | `DESCRIBE jbssdm.pegawai;` |
| Scan siswa tersimpan di `cardscandata.nis` | lihat isi tabel setelah siswa mulai scan |
| Kelas aktif = `kelas.aktif = 1` (tahun ajaran berjalan) | `SELECT replid, kelas, aktif FROM jbsakad.kelas;` |

Pemetaan nama tabel/kolom ada di `config/presensi.php`.

## Aturan yang dipakai (ubah sesuai kebijakan sekolah)
- Masuk = scan pertama hari itu, pulang = scan terakhir (jika hanya satu scan, pulang kosong).
- Terlambat jika scan pertama melewati `PRESENSI_JAM_MASUK` + toleransi.
- "Hari sekolah" = tanggal yang punya minimal satu scan siswa mana pun. Hari ini yang belum ada scan
  ditandai "belum scan", bukan "tidak hadir".
- Guru hanya bisa membuka kelas yang ia walikan (`kelas.nipwali`). Mapel yang diajar belum dicakup.
- Izin/sakit yang diinput di JIBAS belum dibaca; yang tampil murni dari scan fingerprint.

## Keamanan
- Pakai user MySQL read-only untuk JIBAS; jangan pakai `root`. Jangan buka port MySQL ke internet.
- Pasang HTTPS bila diakses dari internet.
- Orang tua hanya bisa membuka NIS yang terhubung ke akunnya (diperiksa di server, bukan hanya di tampilan).
- Akun lokal yang dinonaktifkan atau dihapus admin langsung kehilangan akses pada permintaan berikutnya.
- Hash password JIBAS (MD5) hanya dibandingkan, tidak disimpan. Password akun lokal disimpan dengan bcrypt.
- Pencadangan: salin `database/database.sqlite` secara berkala (berisi akun lokal dan hubungan orang tua-siswa).
