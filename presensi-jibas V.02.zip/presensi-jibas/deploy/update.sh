#!/usr/bin/env bash
# Memperbarui aplikasi yang SUDAH terpasang (tanpa menanyakan ulang pengaturan JIBAS,
# tanpa menimpa .env milik Anda). Jalankan sebagai root dari folder proyek yang baru:
#
#   cd /root/presensi-jibas && bash deploy/update.sh
#
# Yang dilakukan: menyalin kode terbaru, menyiapkan database lokal SQLite (akun admin,
# kesiswaan, orang tua), menjalankan migrasi, lalu menyegarkan cache Laravel.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Jalankan sebagai root." >&2
    exit 1
fi

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${APP_DIR:-/var/www/presensi}"

if [[ ! -f "$APP_DIR/artisan" ]]; then
    echo "Aplikasi belum terpasang di $APP_DIR. Jalankan deploy/install-lxc.sh dulu." >&2
    exit 1
fi

PHP_VER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"

echo "== 1/4 Menyalin kode =="
cp -r "$SRC_DIR/app" "$SRC_DIR/config" "$SRC_DIR/resources" "$SRC_DIR/routes" "$APP_DIR/"
mkdir -p "$APP_DIR/database/migrations" "$APP_DIR/database/demo"
cp "$SRC_DIR"/database/migrations/*.php "$APP_DIR/database/migrations/"
cp -r "$SRC_DIR/database/demo/." "$APP_DIR/database/demo/"
# Berkas lama yang sudah tidak dipakai (digantikan middleware Peran)
rm -f "$APP_DIR/app/Http/Middleware/GuruAuth.php"

cd "$APP_DIR"

echo "== 2/4 Menyiapkan database lokal (SQLite) =="
# Hanya mengubah kunci DB_CONNECTION/DB_DATABASE; pengaturan JIBAS di .env tidak disentuh.
sed -i '/^DB_CONNECTION=/d;/^DB_DATABASE=/d' .env
echo 'DB_CONNECTION=sqlite' >> .env
if ! grep -q '^PRESENSI_TIMEZONE=' .env; then
    echo 'PRESENSI_TIMEZONE="Asia/Jakarta"' >> .env
fi
touch database/database.sqlite
chown -R www-data:www-data database
chmod 775 database

echo "== 3/4 Migrasi =="
php artisan config:clear
runuser -u www-data -- php artisan migrate --force

echo "== 4/4 Cache dan izin =="
runuser -u www-data -- php artisan config:cache
runuser -u www-data -- php artisan route:cache
runuser -u www-data -- php artisan view:cache
chown -R www-data:www-data storage bootstrap/cache database
systemctl reload "php${PHP_VER}-fpm" 2>/dev/null || true
systemctl reload nginx 2>/dev/null || true

echo
echo "Selesai. Jika belum punya akun admin, buat dengan:"
echo "  cd ${APP_DIR} && runuser -u www-data -- php artisan presensi:admin NAMAADMIN --nama=\"Administrator\""
