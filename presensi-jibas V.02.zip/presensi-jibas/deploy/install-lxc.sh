#!/usr/bin/env bash
# Pemasangan otomatis Presensi Fingerprint di LXC Debian 12 (jalankan sebagai root).
#
# Cara pakai (di dalam container):
#   1. Salin seluruh folder presensi-jibas ke container, mis. /root/presensi-jibas
#   2. cd /root/presensi-jibas && bash deploy/install-lxc.sh
#
# Skrip ini: memasang Nginx + PHP-FPM + Composer, membuat proyek Laravel, menyalin
# aplikasi, mengisi .env, dan membuat konfigurasi Nginx. HTTPS (certbot) dijalankan
# hanya jika Anda memilihnya, setelah DNS dan port forwarding siap.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Jalankan sebagai root." >&2
    exit 1
fi

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${APP_DIR:-/var/www/presensi}"

echo "== Pengaturan =="
read -rp "Domain aplikasi (mis. presensi.sekolah.sch.id) [_ = tanpa domain]: " DOMAIN
DOMAIN="${DOMAIN:-_}"
read -rp "Host database JIBAS (IP komputer JIBAS) [127.0.0.1]: " DB_HOST
DB_HOST="${DB_HOST:-127.0.0.1}"
read -rp "Port MySQL [3306]: " DB_PORT
DB_PORT="${DB_PORT:-3306}"
read -rp "User MySQL read-only [presensi_ro]: " DB_USER
DB_USER="${DB_USER:-presensi_ro}"
read -rsp "Password user MySQL: " DB_PASS
echo
read -rp "Pasang HTTPS dengan Let's Encrypt sekarang? (DNS dan port 80/443 harus sudah siap) [y/N]: " DO_SSL
DO_SSL="${DO_SSL:-N}"

echo "== 1/6 Memasang paket =="
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y nginx php-fpm php-cli php-mysql php-mbstring php-xml php-curl php-zip php-sqlite3 \
    unzip curl git composer

PHP_VER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
PHP_SOCK="/run/php/php${PHP_VER}-fpm.sock"
echo "PHP terpasang: ${PHP_VER}"

echo "== 2/6 Membuat proyek Laravel di ${APP_DIR} =="
if [[ ! -f "${APP_DIR}/artisan" ]]; then
    mkdir -p "$APP_DIR"
    COMPOSER_ALLOW_SUPERUSER=1 composer create-project laravel/laravel "$APP_DIR" --no-interaction
else
    echo "Proyek Laravel sudah ada, dilewati."
fi

echo "== 3/6 Menyalin aplikasi presensi =="
cp -r "$SRC_DIR/app" "$SRC_DIR/config" "$SRC_DIR/resources" "$SRC_DIR/routes" "$APP_DIR/"
mkdir -p "$APP_DIR/database/demo"
cp -r "$SRC_DIR/database/demo/." "$APP_DIR/database/demo/"
mkdir -p "$APP_DIR/database/migrations"
cp "$SRC_DIR"/database/migrations/*.php "$APP_DIR/database/migrations/"

echo "== 4/6 Mengisi .env =="
cd "$APP_DIR"
[[ -f .env ]] || cp .env.example .env

# Menulis KEY="nilai" dengan escape agar aman untuk karakter khusus.
set_env() {
    local key="$1" val="$2"
    val="${val//\\/\\\\}"
    val="${val//\"/\\\"}"
    val="${val//\$/\\\$}"
    sed -i "/^${key}=/d" .env
    printf '%s="%s"\n' "$key" "$val" >> .env
}

if [[ "$DOMAIN" == "_" ]]; then
    set_env APP_URL "http://localhost"
else
    set_env APP_URL "https://${DOMAIN}"
fi
set_env APP_ENV production
set_env APP_DEBUG false
set_env APP_LOCALE id
set_env SESSION_DRIVER file
set_env SESSION_SECURE_COOKIE "$([[ "$DOMAIN" == "_" ]] && echo false || echo true)"
set_env CACHE_STORE file
set_env PRESENSI_TIMEZONE Asia/Jakarta
set_env JIBAS_DB_HOST "$DB_HOST"
set_env JIBAS_DB_PORT "$DB_PORT"
set_env JIBAS_DB_USERNAME "$DB_USER"
set_env JIBAS_DB_PASSWORD "$DB_PASS"
set_env JIBAS_DB_AKAD jbsakad
set_env JIBAS_DB_SDM jbssdm
set_env JIBAS_DB_UMUM jbsumum
set_env JIBAS_DB_USER jbsuser
set_env JIBAS_PASSWORD_HASH md5
set_env PRESENSI_JAM_MASUK 07:00
set_env PRESENSI_TOLERANSI 0

php artisan key:generate --force
php artisan config:clear

# Database lokal aplikasi (akun admin, kesiswaan, orang tua): SQLite, terpisah dari JIBAS.
sed -i '/^DB_CONNECTION=/d;/^DB_DATABASE=/d' .env
echo 'DB_CONNECTION=sqlite' >> .env
touch database/database.sqlite
chown -R www-data:www-data "$APP_DIR/database"
chmod 775 "$APP_DIR/database"
runuser -u www-data -- php artisan migrate --force

chown -R www-data:www-data "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"
chmod 640 .env
chown root:www-data .env

echo "== 5/6 Konfigurasi Nginx =="
cat > /etc/nginx/sites-available/presensi <<NGINX
server {
    listen 80;
    server_name ${DOMAIN};
    root ${APP_DIR}/public;
    index index.php;

    client_max_body_size 2m;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;

    location / { try_files \$uri \$uri/ /index.php?\$query_string; }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${PHP_SOCK};
    }

    location ~ /\.(?!well-known) { deny all; }
}
NGINX
ln -sf /etc/nginx/sites-available/presensi /etc/nginx/sites-enabled/presensi
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable --now "php${PHP_VER}-fpm" nginx
systemctl reload nginx

# Cache konfigurasi dan route untuk produksi (setelah .env final)
php artisan config:cache
php artisan route:cache
php artisan view:cache
chown -R www-data:www-data "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"

echo "== 6/6 HTTPS =="
if [[ "$DO_SSL" =~ ^[Yy]$ && "$DOMAIN" != "_" ]]; then
    apt-get install -y certbot python3-certbot-nginx
    certbot --nginx -d "$DOMAIN" --redirect
    systemctl reload nginx
else
    echo "HTTPS dilewati. Setelah DNS dan port forwarding siap, jalankan:"
    echo "  apt install -y certbot python3-certbot-nginx && certbot --nginx -d ${DOMAIN} --redirect"
fi

echo "== Akun admin pertama =="
read -rp "Buat akun admin sekarang? [Y/n]: " BUAT_ADMIN
if [[ ! "${BUAT_ADMIN:-Y}" =~ ^[Nn]$ ]]; then
    read -rp "Username admin: " ADMIN_USER
    runuser -u www-data -- php artisan presensi:admin "$ADMIN_USER" --nama="Administrator" \
        || echo "Gagal membuat admin. Ulangi: cd ${APP_DIR} && runuser -u www-data -- php artisan presensi:admin NAMAADMIN"
fi

echo
echo "Selesai. Alamat aplikasi: $([[ "$DOMAIN" == "_" ]] && echo "http://IP-container" || echo "https://${DOMAIN}")"
echo "Langkah berikut: uji koneksi database dan login (lihat README bagian Asumsi)."
echo "Jika setelah ubah .env perilaku tidak berubah: cd ${APP_DIR} && php artisan config:cache"
