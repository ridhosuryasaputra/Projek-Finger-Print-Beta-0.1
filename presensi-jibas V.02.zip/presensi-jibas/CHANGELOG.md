# Riwayat perubahan

## 0.2.0
### Baru
- Peran **Kepala Sekolah** (`kepsek`): akses setara kesiswaan (ringkasan sekolah, filter kelas, cari siswa).
- Peran **Guru (wali kelas)** sebagai akun lokal: dibuat admin dari menu Pengguna, lengkap dengan pilihan kelas yang diwalikan.
- Tabel lokal `guru_kelas`: penugasan guru ke kelas diatur admin, disimpan di SQLite aplikasi (tanpa foreign key ke JIBAS).
- Pencarian siswa: setiap kata dicocokkan ke NIS atau nama (urutan kata bebas), NIS yang persis sama tampil paling atas.
- `presensi:admin` menerima `--peran=kepsek`.

### Berubah (PERLU DIPERHATIKAN)
- Guru login JIBAS (NIP) kini hanya melihat kelas yang **ditugaskan admin**, tidak lagi otomatis dari kolom wali kelas JIBAS.
  Guru yang belum ditugaskan akan melihat daftar kosong.
- Form pengguna: kolom kelas (guru) dan NIS (orang tua) tampil sesuai peran.

### Perbaikan
- Skrip pemasangan tidak lagi bergantung pada PATH (`/usr/sbin`).

### Tidak berubah
- Aplikasi tetap hanya membaca database JIBAS (SELECT). Semua data akun dan penugasan ada di SQLite lokal.
