@extends('layouts.app')
@section('title', 'Riwayat ' . $siswa->nama)

@php
    $label = ['hadir' => 'Hadir', 'terlambat' => 'Terlambat', 'tidak_hadir' => 'Tidak hadir', 'belum_scan' => 'Belum scan'];
    $css = ['hadir' => 'ok', 'terlambat' => 'warn', 'tidak_hadir' => 'bad', 'belum_scan' => 'muted'];
@endphp

@section('content')
<p><a href="{{ $kembali }}" class="muted">&larr; Kembali</a></p>
<h1>{{ $siswa->nama }}</h1>
<p class="muted">NIS {{ $siswa->nis }} &middot; Kelas {{ $siswa->kelas ?? '-' }}</p>

<div class="card">
    <form class="inline" method="get" action="{{ $aksi }}">
        <input type="month" name="bulan" value="{{ $bulan }}">
        <button type="submit">Tampilkan</button>
    </form>

    <div class="stats">
        <span class="pill ok">Hadir {{ $riwayat['hadir'] }}</span>
        <span class="pill warn">Terlambat {{ $riwayat['terlambat'] }}</span>
        <span class="pill bad">Tidak hadir {{ $riwayat['tidak_hadir'] }}</span>
    </div>
    <p class="muted">Hanya hari sekolah (hari ketika ada scan fingerprint siswa mana pun) yang dihitung.</p>

    <div class="wrap">
        <table>
            <thead><tr><th>Tanggal</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr></thead>
            <tbody>
            @forelse($riwayat['baris'] as $r)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($r->tgl)->translatedFormat('D, j M Y') }}</td>
                    <td>{{ $r->masuk ?? '-' }}</td>
                    <td>{{ $r->pulang ?? '-' }}</td>
                    <td class="{{ $css[$r->status] }}">{{ $label[$r->status] }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="muted">Belum ada data presensi pada bulan ini.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
