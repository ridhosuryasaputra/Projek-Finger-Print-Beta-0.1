@extends('layouts.app')
@section('title', 'Admin')

@section('content')
<h1>Admin</h1>

<div class="card">
    <p class="muted">Akun aktif</p>
    <div class="stats">
        <span class="pill">Admin {{ $hitung['admin'] ?? 0 }}</span>
        <span class="pill">Kesiswaan {{ $hitung['kesiswaan'] ?? 0 }}</span>
        <span class="pill">Orang tua {{ $hitung['ortu'] ?? 0 }}</span>
    </div>
    <p>
        <a class="btn" href="{{ route('admin.pengguna') }}">Kelola pengguna</a>
        <a class="btn ghost" href="{{ route('admin.massal') }}">Buat akun orang tua per kelas</a>
    </p>
    <p class="muted">Guru tidak dikelola di sini: guru masuk dengan NIP dan password JIBAS.</p>
</div>

<div class="card">
    <p><a href="{{ route('kesiswaan.dashboard') }}">Ringkasan presensi sekolah</a> &middot;
       <a href="{{ route('kesiswaan.cari') }}">Cari siswa</a></p>
</div>
@endsection
