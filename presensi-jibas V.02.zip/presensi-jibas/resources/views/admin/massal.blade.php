@extends('layouts.app')
@section('title', 'Akun Orang Tua Massal')

@section('content')
<h1>Buat akun orang tua per kelas</h1>

<div class="card" style="max-width:560px">
    <p>Sistem membuat satu akun untuk setiap siswa aktif di kelas yang dipilih:
       username <strong>ortu + NIS</strong>, password acak. Siswa yang sudah punya akun dilewati.</p>
    <p class="muted">Password hanya tampil sekali di halaman hasil. Cetak atau simpan sebelum menutup halaman,
       lalu minta orang tua mengganti password setelah masuk pertama kali.</p>

    @if($galat)
        <div class="err">{{ $galat }}</div>
    @else
        <form method="post" action="{{ route('admin.massal.proses') }}">
            @csrf
            <label for="idkelas">Kelas</label>
            <select class="field" id="idkelas" name="idkelas" required>
                <option value="">Pilih kelas</option>
                @foreach($kelas as $k)
                    <option value="{{ $k->replid }}">{{ $k->kelas }}</option>
                @endforeach
            </select>
            @error('idkelas') <div class="err">{{ $message }}</div> @enderror
            <p><button type="submit">Buat akun</button></p>
        </form>
    @endif

    <p class="muted">Satu orang tua dengan dua anak: buat akun per kelas seperti di atas, lalu buka
       <a href="{{ route('admin.pengguna') }}">Pengguna</a> dan tambahkan NIS anak kedua ke salah satu akun.</p>
</div>
@endsection
