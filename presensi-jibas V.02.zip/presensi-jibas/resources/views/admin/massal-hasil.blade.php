@extends('layouts.app')
@section('title', 'Hasil Akun Orang Tua')

@section('content')
<h1>Akun orang tua kelas {{ $kelas->kelas }}</h1>

<div class="card">
    <p class="no-print"><strong>{{ count($baru) }}</strong> akun dibuat.
        Password ini tidak akan ditampilkan lagi; cetak atau salin sekarang.</p>
    <p class="no-print">
        <button type="button" onclick="window.print()">Cetak</button>
        <a class="btn ghost" href="{{ route('admin.massal') }}">Kelas lain</a>
    </p>

    @if($baru)
        <div class="wrap">
            <table>
                <thead><tr><th>NIS</th><th>Nama siswa</th><th>Username</th><th>Password</th></tr></thead>
                <tbody>
                @foreach($baru as $b)
                    <tr>
                        <td>{{ $b->nis }}</td>
                        <td>{{ $b->nama }}</td>
                        <td><code>{{ $b->username }}</code></td>
                        <td><code>{{ $b->password }}</code></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    @endif

    @if($dilewati)
        <h2 style="font-size:1rem;margin-top:20px" class="no-print">Dilewati</h2>
        <div class="wrap no-print">
            <table>
                <thead><tr><th>NIS</th><th>Nama siswa</th><th>Alasan</th></tr></thead>
                <tbody>
                @foreach($dilewati as $d)
                    <tr><td>{{ $d->nis }}</td><td>{{ $d->nama }}</td><td class="muted">{{ $d->alasan }}</td></tr>
                @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@endsection
