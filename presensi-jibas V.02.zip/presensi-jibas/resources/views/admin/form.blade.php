@extends('layouts.app')
@section('title', $p ? 'Ubah akun' : 'Tambah akun')

@section('content')
@php $peranSekarang = old('peran', $p->peran ?? 'ortu'); @endphp
<p><a href="{{ route('admin.pengguna') }}" class="muted">&larr; Kembali</a></p>

<div class="card" style="max-width:520px">
    <h1>{{ $p ? 'Ubah akun' : 'Tambah akun' }}</h1>

    <form method="post" action="{{ $aksi }}">
        @csrf
        @if($metode === 'PUT') @method('PUT') @endif

        <label for="username">Username</label>
        @if($p)
            <input class="field" id="username" value="{{ $p->username }}" disabled>
        @else
            <input class="field" id="username" name="username" value="{{ old('username') }}" required>
            @error('username') <div class="err">{{ $message }}</div> @enderror
            <p class="muted">Untuk guru, jangan pakai NIP (misalnya <code>guru.budi</code>).</p>
        @endif

        <label for="nama">Nama</label>
        <input class="field" id="nama" name="nama" value="{{ old('nama', $p->nama ?? '') }}" required>
        @error('nama') <div class="err">{{ $message }}</div> @enderror

        <label for="peran">Peran</label>
        <select class="field" id="peran" name="peran">
            @foreach(['admin' => 'Admin', 'kesiswaan' => 'Kesiswaan', 'kepsek' => 'Kepala Sekolah', 'guru' => 'Guru (wali kelas)', 'ortu' => 'Orang tua'] as $kode => $nama)
                <option value="{{ $kode }}" @selected($peranSekarang === $kode)>{{ $nama }}</option>
            @endforeach
        </select>
        @error('peran') <div class="err">{{ $message }}</div> @enderror

        @if($p)
            <label><input type="checkbox" name="aktif" value="1" @checked(old('aktif', $p->aktif ? '1' : null) === '1')> Akun aktif</label>
        @endif

        <label for="password">{{ $p ? 'Password baru (kosongkan bila tidak diganti)' : 'Password (minimal 8 karakter)' }}</label>
        <input class="field" id="password" type="text" name="password" autocomplete="off" {{ $p ? '' : 'required' }}>
        @error('password') <div class="err">{{ $message }}</div> @enderror

        <div id="blok-kelas" @if($peranSekarang !== 'guru') hidden @endif>
            <label>Kelas yang diwalikan (khusus guru)</label>
            @php $dipilih = array_map('intval', (array) old('kelas', $kelasDipilih)); @endphp
            @forelse($kelas as $k)
                <label style="font-weight:normal">
                    <input type="checkbox" name="kelas[]" value="{{ $k->replid }}" @checked(in_array((int) $k->replid, $dipilih, true))>
                    {{ $k->kelas }}
                </label>
            @empty
                <p class="muted">Daftar kelas tidak tersedia (database JIBAS tidak terjangkau atau belum ada kelas aktif).</p>
            @endforelse
            @error('kelas') <div class="err">{{ $message }}</div> @enderror
        </div>

        <div id="blok-nis" @if($peranSekarang !== 'ortu') hidden @endif>
            <label for="nis">NIS siswa yang terhubung (khusus orang tua; pisahkan dengan koma, spasi, atau baris baru)</label>
            <textarea id="nis" name="nis" rows="3">{{ old('nis', $nis) }}</textarea>
            @error('nis') <div class="err">{{ $message }}</div> @enderror

            @if($siswa->count())
                <p class="muted">Terhubung saat ini:
                    @foreach($siswa as $s){{ $s->nama }} ({{ $s->nis }}, {{ $s->kelas ?? '-' }})@if(! $loop->last); @endif @endforeach
                </p>
            @endif
        </div>

        <p><button type="submit">Simpan</button></p>
    </form>
</div>

<script>
(function () {
    var peran = document.getElementById('peran');
    var nis = document.getElementById('blok-nis');
    var kelas = document.getElementById('blok-kelas');
    function atur() {
        nis.hidden = peran.value !== 'ortu';
        kelas.hidden = peran.value !== 'guru';
    }
    peran.addEventListener('change', atur);
    atur();
})();
</script>
@endsection
