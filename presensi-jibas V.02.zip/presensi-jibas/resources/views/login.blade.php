@extends('layouts.app')
@section('title', 'Masuk - Presensi Fingerprint')

@section('content')
<div class="card" style="max-width:380px;margin:40px auto">
    <h1>Masuk</h1>
    <p class="muted">Guru: NIP dan password JIBAS. Orang tua, kesiswaan, dan admin: akun dari sekolah.</p>
    <form method="post" action="{{ url('/login') }}">
        @csrf
        <p><input name="login" value="{{ old('login') }}" placeholder="NIP / Username" autocomplete="username" style="width:100%" required></p>
        <p><input type="password" name="password" placeholder="Password" autocomplete="current-password" style="width:100%" required></p>
        @error('login') <div class="err">{{ $message }}</div> @enderror
        @error('password') <div class="err">{{ $message }}</div> @enderror
        <button type="submit" style="width:100%">Masuk</button>
    </form>
</div>
@endsection
