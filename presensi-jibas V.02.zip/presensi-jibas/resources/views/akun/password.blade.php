@extends('layouts.app')
@section('title', 'Ganti Password')

@section('content')
<div class="card" style="max-width:420px">
    <h1>Ganti password</h1>
    <form method="post" action="{{ route('akun.password') }}">
        @csrf
        <label for="password_lama">Password lama</label>
        <input class="field" id="password_lama" type="password" name="password_lama" autocomplete="current-password" required>
        @error('password_lama') <div class="err">{{ $message }}</div> @enderror

        <label for="password">Password baru (minimal 8 karakter)</label>
        <input class="field" id="password" type="password" name="password" autocomplete="new-password" required>
        @error('password') <div class="err">{{ $message }}</div> @enderror

        <label for="password_confirmation">Ulangi password baru</label>
        <input class="field" id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" required>

        <p><button type="submit">Simpan</button></p>
    </form>
    <p class="muted">Password guru dikelola di JIBAS dan tidak bisa diganti dari sini.</p>
</div>
@endsection
