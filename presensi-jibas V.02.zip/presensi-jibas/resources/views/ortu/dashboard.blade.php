@extends('layouts.app')
@section('title', 'Anak Saya')

@php
    $label = ['hadir' => 'Hadir', 'terlambat' => 'Terlambat', 'belum_scan' => 'Belum scan'];
    $css = ['hadir' => 'ok', 'terlambat' => 'warn', 'belum_scan' => 'bad'];
@endphp

@section('content')
<h1>Presensi anak hari ini</h1>
<p class="muted">{{ \Carbon\Carbon::parse($hariIni)->translatedFormat('l, j F Y') }}</p>

@forelse($siswa as $s)
    @php $st = $status[(string) $s->nis]; @endphp
    <div class="card">
        <strong>{{ $s->nama }}</strong>
        <div class="muted">NIS {{ $s->nis }} &middot; Kelas {{ $s->kelas ?? '-' }}</div>
        <div class="stats">
            <span class="pill {{ $css[$st->status] }}">{{ $label[$st->status] }}</span>
            @if($st->masuk)<span class="pill">Masuk {{ $st->masuk }}</span>@endif
            @if($st->pulang)<span class="pill">Pulang {{ $st->pulang }}</span>@endif
        </div>
        <a class="btn" href="{{ route('ortu.anak', $s->nis) }}">Riwayat bulanan</a>
    </div>
@empty
    <div class="card">
        <p>Akun Anda belum dihubungkan dengan data siswa. Hubungi admin sekolah.</p>
    </div>
@endforelse
@endsection
