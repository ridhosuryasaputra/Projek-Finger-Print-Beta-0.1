@extends('layouts.app')
@section('title', 'Presensi ' . $kelas->kelas)

@php
    $label = ['hadir' => 'Hadir', 'terlambat' => 'Terlambat', 'belum_scan' => 'Belum scan'];
    $kelasCss = ['hadir' => 'ok', 'terlambat' => 'warn', 'belum_scan' => 'bad'];

    // Dipakai bersama oleh guru dan kesiswaan; controller kesiswaan mengirim nilai lain.
    $rute = $rute ?? 'guru.kelas';
    $kembali = $kembali ?? route('guru.dashboard');
    $linkSiswa = $linkSiswa ?? null;

    $filter = in_array(request('status'), ['hadir', 'terlambat', 'belum_scan'], true) ? request('status') : null;
@endphp

@section('content')
<p><a href="{{ $kembali }}" class="muted">&larr; Kembali</a></p>
<h1>Presensi {{ $kelas->kelas }}</h1>

<p>
    <a class="btn {{ $mode === 'harian' ? '' : 'ghost' }}" href="{{ route($rute, [$kelas->replid, 'mode' => 'harian']) }}">Harian</a>
    <a class="btn {{ $mode === 'bulanan' ? '' : 'ghost' }}" href="{{ route($rute, [$kelas->replid, 'mode' => 'bulanan']) }}">Bulanan</a>
</p>

<div class="card">
@if($mode === 'harian')
    @php $tampil = $filter ? $harian->where('status', $filter)->values() : $harian; @endphp

    <form class="inline" method="get" action="{{ route($rute, $kelas->replid) }}">
        <input type="hidden" name="mode" value="harian">
        <input type="date" name="tanggal" value="{{ $tanggal }}">
        <select name="status">
            <option value="">Semua status</option>
            <option value="hadir" @selected($filter === 'hadir')>Hadir</option>
            <option value="terlambat" @selected($filter === 'terlambat')>Terlambat</option>
            <option value="belum_scan" @selected($filter === 'belum_scan')>Belum scan</option>
        </select>
        <button type="submit">Tampilkan</button>
    </form>

    <div class="stats">
        <span class="pill ok">Hadir {{ $ringkasan['hadir'] }}</span>
        <span class="pill warn">Terlambat {{ $ringkasan['terlambat'] }}</span>
        <span class="pill bad">Belum scan {{ $ringkasan['belum_scan'] }}</span>
        <span class="pill">Total {{ $ringkasan['total'] }}</span>
    </div>

    <div class="wrap">
        <table>
            <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr></thead>
            <tbody>
            @forelse($tampil as $i => $r)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $r->nis }}</td>
                    <td>
                        @if($linkSiswa)
                            <a href="{{ route($linkSiswa, $r->nis) }}">{{ $r->nama }}</a>
                        @else
                            {{ $r->nama }}
                        @endif
                    </td>
                    <td>{{ $r->masuk ?? '-' }}</td>
                    <td>{{ $r->pulang ?? '-' }}</td>
                    <td class="{{ $kelasCss[$r->status] }}">{{ $label[$r->status] }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Tidak ada siswa yang cocok.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@else
    <form class="inline" method="get" action="{{ route($rute, $kelas->replid) }}">
        <input type="hidden" name="mode" value="bulanan">
        <input type="month" name="bulan" value="{{ $bulan }}">
        <button type="submit">Tampilkan</button>
    </form>

    <p class="muted">Hari sekolah pada bulan ini (hari dengan scan): {{ $bulanan['hari_sekolah'] }}</p>

    <div class="wrap">
        <table>
            <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Hadir</th><th>Terlambat</th><th>Tidak hadir</th></tr></thead>
            <tbody>
            @forelse($bulanan['baris'] as $i => $r)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $r->nis }}</td>
                    <td>
                        @if($linkSiswa)
                            <a href="{{ route($linkSiswa, $r->nis) }}">{{ $r->nama }}</a>
                        @else
                            {{ $r->nama }}
                        @endif
                    </td>
                    <td class="ok">{{ $r->hadir }}</td>
                    <td class="warn">{{ $r->terlambat }}</td>
                    <td class="bad">{{ $r->tidak_hadir }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Tidak ada siswa aktif di kelas ini.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endif
</div>
@endsection
