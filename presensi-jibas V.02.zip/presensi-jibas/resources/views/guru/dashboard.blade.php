@extends('layouts.app')
@section('title', 'Dashboard Guru')

@section('content')
<h1>Kelas yang Anda walikan</h1>
<p class="muted">Ringkasan presensi hari ini, {{ \Carbon\Carbon::parse($hariIni)->translatedFormat('l, j F Y') }}</p>

@forelse($kelas as $k)
    <div class="card">
        <strong>{{ $k->kelas }}</strong>
        <div class="stats">
            <span class="pill ok">Hadir {{ $k->ringkasan['hadir'] }}</span>
            <span class="pill warn">Terlambat {{ $k->ringkasan['terlambat'] }}</span>
            <span class="pill bad">Belum scan {{ $k->ringkasan['belum_scan'] }}</span>
            <span class="pill">Total {{ $k->ringkasan['total'] }}</span>
        </div>
        <a class="btn" href="{{ route('guru.kelas', $k->replid) }}">Lihat presensi</a>
    </div>
@empty
    <div class="card">
        <p>Belum ada kelas yang Anda walikan di data JIBAS.</p>
    </div>
@endforelse
@endsection
