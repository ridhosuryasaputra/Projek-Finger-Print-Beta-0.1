@extends('layouts.app')
@section('title', 'Ringkasan Sekolah')

@section('content')
<h1>Ringkasan presensi seluruh sekolah</h1>

<div class="card">
    <form class="inline" method="get" action="{{ route('kesiswaan.dashboard') }}">
        <input type="date" name="tanggal" value="{{ $tanggal }}">
        <button type="submit">Tampilkan</button>
        <a class="btn ghost" href="{{ route('kesiswaan.cari') }}">Cari siswa</a>
    </form>

    <p class="muted">{{ \Carbon\Carbon::parse($tanggal)->translatedFormat('l, j F Y') }}</p>

    <div class="stats">
        <span class="pill ok">Hadir {{ $rekap['total']['hadir'] }}</span>
        <span class="pill warn">Terlambat {{ $rekap['total']['terlambat'] }}</span>
        <span class="pill bad">Belum scan {{ $rekap['total']['belum_scan'] }}</span>
        <span class="pill">Total siswa {{ $rekap['total']['total'] }}</span>
    </div>

    <div class="wrap">
        <table>
            <thead><tr><th>Kelas</th><th>Total</th><th>Hadir</th><th>Terlambat</th><th>Belum scan</th><th>Kehadiran</th></tr></thead>
            <tbody>
            @forelse($rekap['kelas'] as $k)
                @php $persen = $k->total ? round(($k->hadir + $k->terlambat) / $k->total * 100) : 0; @endphp
                <tr>
                    <td><a href="{{ route('kesiswaan.kelas', [$k->replid, 'tanggal' => $tanggal]) }}">{{ $k->kelas }}</a></td>
                    <td>{{ $k->total }}</td>
                    <td class="ok">{{ $k->hadir }}</td>
                    <td class="warn">{{ $k->terlambat }}</td>
                    <td class="bad">{{ $k->belum_scan }}</td>
                    <td>{{ $persen }}%</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Belum ada kelas aktif di data JIBAS.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
