@extends('layouts.app')
@section('title', 'Cari Siswa')

@section('content')
<h1>Cari siswa</h1>

<div class="card">
    <form class="inline" method="get" action="{{ route('kesiswaan.cari') }}">
        <input type="search" name="q" value="{{ $q }}" placeholder="Nama atau NIS" style="min-width:240px" autofocus>
        <button type="submit">Cari</button>
    </form>

    @if($pesan)
        <div class="err">{{ $pesan }}</div>
    @elseif($hasil !== null)
        <div class="wrap">
            <table>
                <thead><tr><th>NIS</th><th>Nama</th><th>Kelas</th></tr></thead>
                <tbody>
                @forelse($hasil as $s)
                    <tr>
                        <td>{{ $s->nis }}</td>
                        <td><a href="{{ route('kesiswaan.siswa', $s->nis) }}">{{ $s->nama }}</a></td>
                        <td>{{ $s->kelas ?? '-' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="3" class="muted">Tidak ada siswa aktif yang cocok.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
        @if($hasil->count() >= 30)
            <p class="muted">Menampilkan 30 hasil pertama. Persempit kata kuncinya bila perlu.</p>
        @endif
    @else
        <p class="muted">Ketik minimal 2 huruf nama atau angka NIS.</p>
    @endif
</div>
@endsection
