package id.sch.smkmuh2metro.presensilogin

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var errorView: View

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        refresh = findViewById(R.id.refresh)
        progress = findViewById(R.id.progress)
        errorView = findViewById(R.id.error_view)

        // Sesi login (cookie) disimpan agar pengguna tidak perlu masuk berulang.
        CookieManager.getInstance().setAcceptCookie(true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                // Halaman milik server sekolah dibuka di dalam aplikasi, selain itu di browser.
                if (uri.host == BuildConfig.HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: ActivityNotFoundException) {
                }
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                refresh.isRefreshing = false
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) tampilkanGagal()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }
        }

        // Unduhan (mis. ekspor Excel) disimpan ke folder Unduhan dengan membawa sesi login.
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            unduh(url, userAgent, contentDisposition, mimeType)
        }

        // Tarik ke bawah untuk memuat ulang, hanya bila halaman sudah di posisi paling atas.
        refresh.setColorSchemeColors(0xFF1A64E0.toInt())
        refresh.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }
        refresh.setOnRefreshListener { muatUlang() }

        findViewById<Button>(R.id.btn_coba_lagi).setOnClickListener { muatUlang() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.URL_AWAL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun unduh(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        val nama = URLUtil.guessFileName(url, contentDisposition, mimeType)
        Toast.makeText(this, "Mengunduh $nama...", Toast.LENGTH_SHORT).show()

        thread {
            var uri: Uri? = null
            val pesan = try {
                val koneksi = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 60000
                    CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
                    if (!userAgent.isNullOrEmpty()) setRequestProperty("User-Agent", userAgent)
                }
                if (koneksi.responseCode !in 200..299) throw IOException("kode ${koneksi.responseCode}")

                val tipe = koneksi.contentType?.substringBefore(';')?.trim()
                    ?: mimeType ?: "application/octet-stream"
                val nilai = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, nama)
                    put(MediaStore.Downloads.MIME_TYPE, tipe)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, nilai)
                    ?: throw IOException("tidak bisa membuat file")
                contentResolver.openOutputStream(uri!!)?.use { keluar ->
                    koneksi.inputStream.use { masuk -> masuk.copyTo(keluar) }
                } ?: throw IOException("tidak bisa menulis file")
                koneksi.disconnect()

                nilai.clear()
                nilai.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri!!, nilai, null, null)
                "Tersimpan di folder Unduhan: $nama"
            } catch (e: Exception) {
                uri?.let { runCatching { contentResolver.delete(it, null, null) } }
                "Unduhan gagal: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, pesan, Toast.LENGTH_LONG).show() }
        }
    }

    private fun tampilkanGagal() {
        progress.visibility = View.GONE
        refresh.isRefreshing = false
        errorView.visibility = View.VISIBLE
    }

    private fun muatUlang() {
        errorView.visibility = View.GONE
        if (webView.url == null) webView.loadUrl(BuildConfig.URL_AWAL) else webView.reload()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
