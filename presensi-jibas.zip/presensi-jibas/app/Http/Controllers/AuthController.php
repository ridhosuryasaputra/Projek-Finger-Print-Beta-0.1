<?php

namespace App\Http\Controllers;

use App\Services\PresensiService;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function form(Request $request)
    {
        if ($request->session()->has('guru_nip')) {
            return redirect()->route('guru.dashboard');
        }

        return view('login');
    }

    public function login(Request $request, PresensiService $presensi)
    {
        $data = $request->validate([
            'login'    => 'required|string|max:30',
            'password' => 'required|string|max:100',
        ]);

        $guru = $presensi->cekLogin($data['login'], $data['password']);

        if (! $guru) {
            return back()->withErrors(['login' => 'Login atau password salah.'])->onlyInput('login');
        }

        $request->session()->regenerate();
        $request->session()->put('guru_nip', $guru['nip']);
        $request->session()->put('guru_nama', $guru['nama']);

        return redirect()->route('guru.dashboard');
    }

    public function logout(Request $request)
    {
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
