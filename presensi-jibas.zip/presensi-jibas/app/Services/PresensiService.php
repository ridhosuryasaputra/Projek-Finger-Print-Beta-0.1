<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Collection;

class PresensiService
{
    /**
     * Cek login guru. Login JIBAS dianggap sama dengan NIP pegawai.
     * Mengembalikan ['nip' => ..., 'nama' => ...] atau null.
     */
    public function cekLogin(string $login, string $password): ?array
    {
        $user = Jibas::db()->table(Jibas::t('user', 'login'))
            ->where('login', $login)
            ->where('aktif', 1)
            ->first();

        if (! $user || ! $this->passwordCocok($password, (string) $user->password)) {
            return null;
        }

        $p = config('presensi.pegawai');
        $pegawai = Jibas::db()->table(Jibas::t('sdm', $p['table']))
            ->where($p['nip'], $login)
            ->first([$p['nip'] . ' as nip', $p['nama'] . ' as nama']);

        // Hanya pegawai (guru) yang boleh masuk.
        if (! $pegawai) {
            return null;
        }

        return ['nip' => $pegawai->nip, 'nama' => $pegawai->nama];
    }

    private function passwordCocok(string $input, string $tersimpan): bool
    {
        $hash = match (config('presensi.password_hash')) {
            'md5'   => md5($input),
            'sha1'  => sha1($input),
            default => $input,
        };

        return hash_equals(strtolower($tersimpan), strtolower($hash));
    }

    /** Kelas aktif yang diwalikan guru. */
    public function kelasWali(string $nip): Collection
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('nipwali', $nip)
            ->where('aktif', 1)
            ->orderBy('kelas')
            ->get(['replid', 'kelas']);
    }

    public function kelasMilik(string $nip, int $idkelas): ?object
    {
        return Jibas::db()->table(Jibas::t('akad', 'kelas'))
            ->where('replid', $idkelas)
            ->where('nipwali', $nip)
            ->first(['replid', 'kelas']);
    }

    public function siswaKelas(int $idkelas): Collection
    {
        $c = config('presensi.siswa');

        return Jibas::db()->table(Jibas::t('akad', $c['table']))
            ->where($c['kelas'], $idkelas)
            ->where($c['aktif'], 1)
            ->orderBy($c['nama'])
            ->get([$c['nis'] . ' as nis', $c['nama'] . ' as nama']);
    }

    /** Scan pertama (masuk) dan terakhir (pulang) per siswa per tanggal. */
    private function scanPerHari(array $nisList, string $dari, string $sampai): Collection
    {
        if (! $nisList) {
            return collect();
        }

        return Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->selectRaw('nis, DATE(jam) as tgl, MIN(jam) as masuk, MAX(jam) as pulang')
            ->whereIn('nis', $nisList)
            ->whereBetween('jam', ["$dari 00:00:00", "$sampai 23:59:59"])
            ->groupBy('nis', 'tgl')
            ->get();
    }

    private function terlambat(string $masuk): bool
    {
        $tanggal = substr($masuk, 0, 10);
        $batas = Carbon::parse($tanggal . ' ' . config('presensi.jam_masuk'))
            ->addMinutes(config('presensi.toleransi_menit'));

        return Carbon::parse($masuk)->gt($batas);
    }

    /**
     * Rekap satu hari. Status: hadir | terlambat | belum_scan.
     * Jika hanya ada satu scan, pulang = null.
     */
    public function rekapHarian(int $idkelas, string $tanggal): Collection
    {
        $siswa = $this->siswaKelas($idkelas);
        $scan = $this->scanPerHari($siswa->pluck('nis')->all(), $tanggal, $tanggal)->keyBy('nis');

        return $siswa->map(function ($s) use ($scan) {
            $r = $scan->get($s->nis);
            if (! $r) {
                return (object) ['nis' => $s->nis, 'nama' => $s->nama, 'masuk' => null, 'pulang' => null, 'status' => 'belum_scan'];
            }

            return (object) [
                'nis'    => $s->nis,
                'nama'   => $s->nama,
                'masuk'  => substr($r->masuk, 11, 5),
                'pulang' => $r->pulang !== $r->masuk ? substr($r->pulang, 11, 5) : null,
                'status' => $this->terlambat($r->masuk) ? 'terlambat' : 'hadir',
            ];
        });
    }

    public function ringkasan(Collection $rekapHarian): array
    {
        return [
            'total'      => $rekapHarian->count(),
            'hadir'      => $rekapHarian->where('status', 'hadir')->count(),
            'terlambat'  => $rekapHarian->where('status', 'terlambat')->count(),
            'belum_scan' => $rekapHarian->where('status', 'belum_scan')->count(),
        ];
    }

    /**
     * Rekap bulanan per siswa. "Hari sekolah" dihitung dari tanggal yang punya
     * minimal satu scan siswa mana pun di sekolah pada bulan itu.
     */
    public function rekapBulanan(int $idkelas, string $bulan): array
    {
        $awal = Carbon::createFromFormat('Y-m-d', $bulan . '-01')->startOfMonth();
        $dari = $awal->toDateString();
        $sampai = $awal->copy()->endOfMonth()->toDateString();

        $hariSekolah = Jibas::db()->table(Jibas::t('umum', 'cardscandata'))
            ->whereNotNull('nis')
            ->whereBetween('jam', ["$dari 00:00:00", "$sampai 23:59:59"])
            ->selectRaw('DATE(jam) as tgl')
            ->distinct()
            ->get()
            ->count();

        $siswa = $this->siswaKelas($idkelas);
        $scan = $this->scanPerHari($siswa->pluck('nis')->all(), $dari, $sampai)->groupBy('nis');

        $baris = $siswa->map(function ($s) use ($scan, $hariSekolah) {
            $hari = $scan->get($s->nis, collect());
            $telat = $hari->filter(fn ($h) => $this->terlambat($h->masuk))->count();
            $hadirTotal = $hari->count();

            return (object) [
                'nis'         => $s->nis,
                'nama'        => $s->nama,
                'hadir'       => $hadirTotal - $telat,
                'terlambat'   => $telat,
                'tidak_hadir' => max($hariSekolah - $hadirTotal, 0),
            ];
        });

        return ['hari_sekolah' => $hariSekolah, 'baris' => $baris];
    }
}
