# Presensi Fingerprint (Laravel) - Tahap 1: Peran Guru

Aplikasi web **read-only** untuk menampilkan hasil presensi fingerprint dari database JIBAS.
Tahap ini: guru login (akun JIBAS), melihat presensi siswa kelas yang diwalikan (harian dan bulanan).

Status: semua file PHP lolos `php -l`. **Belum diuji jalan** (Laravel dan database tidak tersedia
saat pembuatan), jadi lakukan uji dengan data contoh dulu (langkah 4).

## Pemasangan cepat di Proxmox LXC (Debian 12)
1. Buat LXC dari template Debian 12 (unprivileged, 1 core, 1 GB RAM, disk 8 GB, IP statis).
2. Salin folder ini ke container, lalu: `bash deploy/install-lxc.sh` (sebagai root).
3. Skrip menanyakan domain, host/user/password MySQL JIBAS, dan apakah HTTPS dipasang sekarang.
4. Router: forward TCP 80 dan 443 ke IP container. Jangan forward 3306.
5. Firewall dipasang di level Proxmox (Datacenter/Node/CT > Firewall), bukan ufw di dalam LXC.
6. Setelah teruji, ambil snapshot dan jadwalkan backup container.

## Persyaratan
PHP 8.2+, Composer, Laravel 11 atau 12, akses ke MySQL/MariaDB JIBAS.

## Pemasangan
1. Buat proyek Laravel baru:
   `composer create-project laravel/laravel presensi`
2. Salin isi folder ini ke dalam proyek (timpa `routes/web.php`; folder `app`, `config`, `resources` digabung).
   Tidak ada file inti Laravel yang perlu diedit.
3. Tambahkan isi `.env.presensi.example` ke `.env`, lalu `php artisan key:generate`.
4. **Uji dengan data contoh dulu** (di MySQL terpisah, bukan server JIBAS produksi):
   - jalankan `database/demo/demo_jibas.sql`
   - di `.env` set `JIBAS_DB_AKAD=demo_jbsakad`, `JIBAS_DB_SDM=demo_jbssdm`, `JIBAS_DB_UMUM=demo_jbsumum`, `JIBAS_DB_USER=demo_jbsuser`, dan user/password MySQL Anda
   - `php artisan serve`, buka http://127.0.0.1:8000, login **198501012010011001 / guru123**
5. Untuk data asli: buat user read-only dengan `database/demo/user_readonly.sql`, kembalikan nama skema ke `jbsakad` dst, lalu isi `JIBAS_DB_USERNAME` dan `JIBAS_DB_PASSWORD`.

## Asumsi yang HARUS diverifikasi di server JIBAS Anda
Jalankan di SQLyog dan sesuaikan `config/presensi.php` / `.env` bila hasilnya berbeda:

| Asumsi | Cek |
|---|---|
| Password di `jbsuser.login` berupa MD5 | `SELECT login, password FROM jbsuser.login LIMIT 3;` (MD5 = 32 karakter hex) |
| `login` guru = NIP di `jbssdm.pegawai` | `SELECT nip, nama FROM jbssdm.pegawai LIMIT 5;` bandingkan dengan isi `login` |
| Kolom tabel siswa: `nis`, `nama`, `idkelas`, `aktif` | `DESCRIBE jbsakad.siswa;` |
| Kolom pegawai: `nip`, `nama` | `DESCRIBE jbssdm.pegawai;` |
| Scan siswa tersimpan di `cardscandata.nis` | lihat isi tabel setelah siswa mulai scan |

## Aturan yang dipakai (ubah sesuai kebijakan sekolah)
- Masuk = scan pertama hari itu, pulang = scan terakhir (jika hanya satu scan, pulang kosong).
- Terlambat jika scan pertama melewati `PRESENSI_JAM_MASUK` + toleransi.
- "Hari sekolah" bulan itu = tanggal yang punya minimal satu scan siswa mana pun.
- Guru hanya bisa membuka kelas yang ia walikan (`kelas.nipwali`). Mapel yang diajar belum dicakup.

## Keamanan
- Pakai user MySQL read-only; jangan pakai `root`.
- Pasang HTTPS bila diakses dari internet. Jangan buka port MySQL JIBAS ke internet.
- MD5 adalah hash lemah milik JIBAS; aplikasi ini hanya membandingkannya, tidak menyimpan password.

## Tahap berikutnya
Peran kesiswaan, admin, dan orang tua (satu akun hanya melihat anaknya), ekspor Excel/PDF.
