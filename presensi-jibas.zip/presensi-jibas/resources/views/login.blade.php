@extends('layouts.app')
@section('title', 'Masuk - Presensi Fingerprint')

@section('content')
<div class="card" style="max-width:380px;margin:40px auto">
    <h1>Masuk Guru</h1>
    <p class="muted">Gunakan akun JIBAS Anda (NIP dan password).</p>
    <form method="post" action="{{ url('/login') }}">
        @csrf
        <p><input name="login" value="{{ old('login') }}" placeholder="NIP" autocomplete="username" style="width:100%" required></p>
        <p><input type="password" name="password" placeholder="Password" autocomplete="current-password" style="width:100%" required></p>
        @error('login') <div class="err">{{ $message }}</div> @enderror
        @error('password') <div class="err">{{ $message }}</div> @enderror
        <button type="submit" style="width:100%">Masuk</button>
    </form>
</div>
@endsection
