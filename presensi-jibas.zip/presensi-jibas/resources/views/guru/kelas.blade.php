@extends('layouts.app')
@section('title', 'Presensi ' . $kelas->kelas)

@php
    $label = ['hadir' => 'Hadir', 'terlambat' => 'Terlambat', 'belum_scan' => 'Belum scan'];
    $kelasCss = ['hadir' => 'ok', 'terlambat' => 'warn', 'belum_scan' => 'bad'];
@endphp

@section('content')
<p><a href="{{ route('guru.dashboard') }}" class="muted">&larr; Kembali</a></p>
<h1>Presensi {{ $kelas->kelas }}</h1>

<p>
    <a class="btn {{ $mode === 'harian' ? '' : 'ghost' }}" href="{{ route('guru.kelas', [$kelas->replid, 'mode' => 'harian']) }}">Harian</a>
    <a class="btn {{ $mode === 'bulanan' ? '' : 'ghost' }}" href="{{ route('guru.kelas', [$kelas->replid, 'mode' => 'bulanan']) }}">Bulanan</a>
</p>

<div class="card">
@if($mode === 'harian')
    <form class="inline" method="get" action="{{ route('guru.kelas', $kelas->replid) }}">
        <input type="hidden" name="mode" value="harian">
        <input type="date" name="tanggal" value="{{ $tanggal }}">
        <button type="submit">Tampilkan</button>
    </form>

    <div class="stats">
        <span class="pill ok">Hadir {{ $ringkasan['hadir'] }}</span>
        <span class="pill warn">Terlambat {{ $ringkasan['terlambat'] }}</span>
        <span class="pill bad">Belum scan {{ $ringkasan['belum_scan'] }}</span>
        <span class="pill">Total {{ $ringkasan['total'] }}</span>
    </div>

    <div class="wrap">
        <table>
            <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr></thead>
            <tbody>
            @forelse($harian as $i => $r)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $r->nis }}</td>
                    <td>{{ $r->nama }}</td>
                    <td>{{ $r->masuk ?? '-' }}</td>
                    <td>{{ $r->pulang ?? '-' }}</td>
                    <td class="{{ $kelasCss[$r->status] }}">{{ $label[$r->status] }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Tidak ada siswa aktif di kelas ini.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@else
    <form class="inline" method="get" action="{{ route('guru.kelas', $kelas->replid) }}">
        <input type="hidden" name="mode" value="bulanan">
        <input type="month" name="bulan" value="{{ $bulan }}">
        <button type="submit">Tampilkan</button>
    </form>

    <p class="muted">Hari sekolah pada bulan ini (hari dengan scan): {{ $bulanan['hari_sekolah'] }}</p>

    <div class="wrap">
        <table>
            <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Hadir</th><th>Terlambat</th><th>Tidak hadir</th></tr></thead>
            <tbody>
            @forelse($bulanan['baris'] as $i => $r)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $r->nis }}</td>
                    <td>{{ $r->nama }}</td>
                    <td class="ok">{{ $r->hadir }}</td>
                    <td class="warn">{{ $r->terlambat }}</td>
                    <td class="bad">{{ $r->tidak_hadir }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Tidak ada siswa aktif di kelas ini.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endif
</div>
@endsection
