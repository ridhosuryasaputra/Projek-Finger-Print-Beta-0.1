<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\GuruController;
use App\Http\Middleware\GuruAuth;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('guru.dashboard'));

Route::get('/login', [AuthController::class, 'form'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware(GuruAuth::class)->prefix('guru')->group(function () {
    Route::get('/', [GuruController::class, 'dashboard'])->name('guru.dashboard');
    Route::get('/kelas/{idkelas}', [GuruController::class, 'kelas'])
        ->whereNumber('idkelas')
        ->name('guru.kelas');
});
