<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Presensi Fingerprint')</title>
    <style>
        :root { --bg:#f4f6f9; --card:#fff; --text:#1f2937; --muted:#6b7280; --line:#e5e7eb;
                --brand:#1d4ed8; --ok:#15803d; --warn:#b45309; --bad:#b91c1c; }
        @media (prefers-color-scheme: dark) {
            :root { --bg:#111827; --card:#1f2937; --text:#f3f4f6; --muted:#9ca3af; --line:#374151;
                    --brand:#60a5fa; --ok:#4ade80; --warn:#fbbf24; --bad:#f87171; }
        }
        * { box-sizing: border-box; }
        body { margin:0; font-family: system-ui, sans-serif; background:var(--bg); color:var(--text); }
        header { background:var(--card); border-bottom:1px solid var(--line); padding:10px 16px;
                 display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; }
        header a { color:var(--text); text-decoration:none; }
        header .brand { font-weight:700; }
        nav { display:flex; gap:14px; flex-wrap:wrap; font-size:.92rem; }
        nav a { color:var(--brand); }
        main { max-width:960px; margin:0 auto; padding:16px; }
        .card { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:16px; margin-bottom:16px; }
        h1 { font-size:1.25rem; margin:0 0 12px; }
        a { color:var(--brand); }
        .muted { color:var(--muted); font-size:.9rem; }
        .grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:12px; }
        .stats { display:flex; gap:8px; flex-wrap:wrap; margin:8px 0; }
        .pill { padding:2px 10px; border-radius:999px; font-size:.85rem; border:1px solid var(--line); }
        .ok { color:var(--ok); } .warn { color:var(--warn); } .bad { color:var(--bad); }
        table { width:100%; border-collapse:collapse; font-size:.95rem; }
        th, td { text-align:left; padding:8px; border-bottom:1px solid var(--line); vertical-align:top; }
        .wrap { overflow-x:auto; }
        input, select, textarea, button { font:inherit; padding:8px 10px; border-radius:8px; border:1px solid var(--line);
                                background:var(--card); color:var(--text); }
        textarea { width:100%; }
        button, .btn { background:var(--brand); color:#fff; border:0; cursor:pointer; text-decoration:none;
                       display:inline-block; padding:8px 14px; border-radius:8px; }
        .btn.ghost { background:transparent; color:var(--brand); border:1px solid var(--brand); }
        .btn.danger { background:var(--bad); }
        form.inline { display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom:12px; }
        .err { color:var(--bad); margin:8px 0; }
        .flash { border-color:var(--ok); color:var(--ok); }
        label { display:block; margin:12px 0 4px; font-size:.9rem; }
        .field { width:100%; }
        @media print {
            header, .no-print { display:none !important; }
            body { background:#fff; color:#000; }
            .card { border:0; padding:0; }
        }
    </style>
</head>
<body>
@php
    $peran = session('peran');
    $labelPeran = ['guru' => 'Guru', 'kesiswaan' => 'Kesiswaan', 'admin' => 'Admin', 'ortu' => 'Orang tua'];
    $menu = match ($peran) {
        'guru'      => [['Kelas saya', route('guru.dashboard')]],
        'kesiswaan' => [['Ringkasan sekolah', route('kesiswaan.dashboard')], ['Cari siswa', route('kesiswaan.cari')], ['Ganti password', route('akun.password')]],
        'admin'     => [['Pengguna', route('admin.pengguna')], ['Akun orang tua massal', route('admin.massal')], ['Ringkasan sekolah', route('kesiswaan.dashboard')], ['Cari siswa', route('kesiswaan.cari')], ['Ganti password', route('akun.password')]],
        'ortu'      => [['Anak saya', route('ortu.dashboard')], ['Ganti password', route('akun.password')]],
        default     => [],
    };
@endphp
<header>
    <a href="{{ route('beranda') }}" class="brand">Presensi Fingerprint</a>
    @if($peran)
        <nav>
            @foreach($menu as $m)
                <a href="{{ $m[1] }}">{{ $m[0] }}</a>
            @endforeach
        </nav>
        <form method="post" action="{{ route('logout') }}" class="inline" style="margin:0">
            @csrf
            <span class="muted">{{ session('nama') }} ({{ $labelPeran[$peran] ?? $peran }})</span>
            <button type="submit" class="btn ghost">Keluar</button>
        </form>
    @endif
</header>
<main>
    @if(session('ok'))
        <div class="card flash">{{ session('ok') }}</div>
    @endif
    @yield('content')
</main>
</body>
</html>
