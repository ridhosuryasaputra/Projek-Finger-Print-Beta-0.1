@extends('layouts.app')
@section('title', 'Pengguna')

@php $labelPeran = ['admin' => 'Admin', 'kesiswaan' => 'Kesiswaan', 'ortu' => 'Orang tua']; @endphp

@section('content')
<h1>Pengguna</h1>

<div class="card">
    <form class="inline" method="get" action="{{ route('admin.pengguna') }}">
        <select name="peran">
            <option value="">Semua peran</option>
            @foreach($labelPeran as $kode => $nama)
                <option value="{{ $kode }}" @selected($peran === $kode)>{{ $nama }}</option>
            @endforeach
        </select>
        <input type="search" name="q" value="{{ $q }}" placeholder="Username atau nama">
        <button type="submit">Cari</button>
        <a class="btn ghost" href="{{ route('admin.pengguna.buat') }}">Tambah akun</a>
    </form>

    @if($errors->any())
        <div class="err">{{ $errors->first() }}</div>
    @endif

    <div class="wrap">
        <table>
            <thead><tr><th>Username</th><th>Nama</th><th>Peran</th><th>Status</th><th>NIS terhubung</th><th></th></tr></thead>
            <tbody>
            @forelse($daftar as $d)
                <tr>
                    <td>{{ $d->username }}</td>
                    <td>{{ $d->nama }}</td>
                    <td>{{ $labelPeran[$d->peran] ?? $d->peran }}</td>
                    <td class="{{ $d->aktif ? 'ok' : 'bad' }}">{{ $d->aktif ? 'Aktif' : 'Nonaktif' }}</td>
                    <td>{{ $d->nis ? implode(', ', $d->nis) : '-' }}</td>
                    <td style="white-space:nowrap">
                        <a href="{{ route('admin.pengguna.ubah', $d->id) }}">Ubah</a>
                        <form method="post" action="{{ route('admin.pengguna.hapus', $d->id) }}" style="display:inline"
                              onsubmit="return confirm('Hapus akun {{ $d->username }}? Tindakan ini tidak bisa dibatalkan.')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn danger" style="padding:2px 8px">Hapus</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="muted">Tidak ada akun yang cocok.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <p class="muted">Menampilkan maksimal 200 akun; gunakan pencarian untuk mempersempit.</p>
</div>
@endsection
